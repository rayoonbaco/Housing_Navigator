# Targeted San Francisco source acquisition — 2026-10-04

No production rules, predicates, lookups, existing logs, or live API calls were changed. This is an append-only evidence acquisition return, not an approved precedence edge.

## What the rejected review actually needs

The 04:39:14 independent review correctly refused to promote a pair whose priority condition was unknown. It also identified a source-authority gap: the chapter-wide finding was only in a 2024 agency compilation, and later amendments were unresolved. The new final enacted sources below materially improve those inputs.

| Source | Verified acquisition | Useful evidence | Remaining limit |
|---|---|---|---|
| SF Ordinance 18-22, File 211265 | Official Board of Supervisors final PDF; raw bytes and extracted text retained | Section 2 adds Chapter 37.1(d), a chapter-wide more-protective finding and intent that Chapter 37 apply rather than Civil Code 1946.2. It is broader evidence than the narrow 296-19 extension finding. Final passage February 1, 2022; enacted February 11, 2022 per legislative record; published code history effective March 14, 2022. | It uses the historical state subsection reference 1946.2(g)(1)(B). Independent review must evaluate the current state text's renamed subsection (i), rather than assume this is fatal or silently rewrite the citation. This ordinance is an amendment, not a complete contemporary chapter. |
| SF Ordinance 3-26, File 250926 | Official city-hosted final PDF; raw bytes and extracted text retained | Final passage January 6, 2026; amendments to 37.2, 37.3, 37.8B, 37.9, 37.9A, 37.9E. Includes expanded definition concerning regulatory agreements and replacement units, new demolition grounds, relocation protections and other changes. Publisher histories list approval January 8 and effective February 8, 2026. | PDF is legislative markup, with omitted unchanged portions and OCR artifacts. It must not be flattened into a fabricated consolidated code. A city news search snippet said February 9, one day different; retain that discrepancy if discussing effective dates until checked. |
| City Attorney municipal-code link | Rendered city page captured | SFGOV directs the public to the American Legal San Francisco code library. | This establishes the city's designated access point, not a guarantee the publication contains every uncodified enactment. |
| Publisher 37.2 / 37.9 | Search-tool rendered excerpts captured | Current 37.9 history runs through 3-26, effective February 8, 2026. Current content contains the 2026 additions. | Direct raw HTML fetch returned 403. Repeated rendered fetching of 37.1/37.2 timed out. Captures are incomplete excerpts, not full raw publisher sections. |

Receipts and raw/text hashes are in `sources/download-manifest.json`; integrity verification is in `sources/verification.json`. All six downloaded raw/text hash checks passed. The committee agenda packet initially found through Legistar was identified as a draft packet and renamed explicitly; it is excluded from proof of final enactment. Only `sf-0018-22-final.pdf` is the final seven-page 18-22 enactment.

## Bounded useful next action

1. Repair the pair proposal's structural contract before another paid call. The prior proposal used `{"all": ...}` / `{"cmp": ...}` and `comparison: "=="`; the evaluator requires explicit `op`, `args`, and the supported comparison enum. The independent reviewer rejected it legally, so no invalid production predicate was promoted. The next runner should deterministically validate any proposal before asking a second model to review it.
2. Add final 18-22 to the one-pair source material, with the current CA 1946.2(i) text, final 3-26 amendments, and the existing full 2024 compilation clearly labeled as the base compilation. Keep amendment text separate with all markup, URLs, retrieval dates and hashes. No automatic consolidation or manually authored legal edge.
3. Ask at most two independent calls to assess the **legal relationship**, separately from property eligibility. A chapter-wide finding can support a priority relationship without proving that any of the 500 sample properties meets rental-unit coverage. Missing ownership, tenancy, subsidy and other facts must remain unknown. No rent-cap-minimum calculation and no blanket apartment inference.
4. Promote only through existing evidence gates after independent support. Keep the prior uncertain review and prior lookups intact. A rejected relationship remains explicit; source-backed factual acquisition is progress even if sample applicability remains unknown.

## What cannot yet be claimed

This acquisition does not certify every amendment, uncodified ordinance, injunction or other litigation effect through the frozen challenge date 2026-10-01. The publisher expressly disclaims completeness/currentness. Full current 37.2 exclusions and 37.9 were not captured as one complete authoritative raw section, although the existing complete 2024 agency text plus final 2026 amendments provide a bounded candidate review package. No production superseded result, no approved local coverage refinement, and no legal accuracy score follows from these downloads.

The official 2022 source also concerns a ten-day cure provision subject to litigation reported by the Rent Board. This acquisition makes no claim about the enforceability of that cure requirement; it targets the distinct 37.1(d) finding and retains severability text in the final ordinance. A full status audit should separately inspect current litigation authority before publishing a cure-period claim.

## Evidence locations

- Prior decision: `latest-release-v1/precedence-pair-v1/20261004T043914-9f520b30/independent-review.json`
- Original pair runner and gate: `work/precedence-pair/review_pair.py`, `pair_gate.py`
- New enacted finding: `sources/sf-0018-22-final.pdf` and `.txt`
- New 2026 amendments: `sources/sf-0003-26-final.pdf` and `.txt`
- Rendered publisher/city metadata: `sources/web-captures*.json` (incomplete excerpts; preserved errors)

