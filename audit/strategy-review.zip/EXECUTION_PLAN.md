# Implementation plan after review

All windows below are EDT Oct4,2026 and are targets, not guarantees. Keep earlier sources/logs/output versions. Main deadline9AM; grace not part of the plan. Working cutoff7:30AM. Deploy before final recording.

| Window | Deliverable | Acceptance / fallback |
|---|---|---|
| Now–12:45AM | Targeted T2 evidence/eligibility diagnosis and governing-law relationship audit | Identify exact fact dependencies and source gaps; seek public property evidence where needed; repair supported logic, no residential-label substitution. Unknown stays explicit when necessary. |
|12:45–2AM| Targeted pipeline improvements and source/penalty/temporal coverage ledger | Freeze canonical records; test specific corrected predicates/precedence edges. Preserve baseline; no broad rereview of310rules. |
|2–4AM| Resident view and claim-level explanations | Six practical questions, visible decisive qualifications, scoped Check my homework, explicit unknown reasons. Evidence-reviewed prose only; raw audit stays accessible. |
|4–5:30AM| Actual-data regression/browser/accessibility plus repository/deployment |500addresses intact; saved dates synchronize; exact receipts and safe links; demonstrate pending/future/failed/conflict. Public URL and repository access verified. |
|5:30–7AM| Current method note/scripts and three videos | Intro personal; demo resident answer/evidence/change; technical pipeline and limits. Watch actual files and verify<=60sec each. |
|7–7:30AM| Final release/access/required-field check | GitHub/Render links, photo, allJSONoutputs, method note, Google Form fields, recording files ready. |
|7:30–9AM| Upload, both submissions and receipts | Stop new features. Resolve upload/access issues; retain submission confirmations. |

Parallelism: evidence and resident implementation can proceed from an agreed contract, with immutable source/output inputs; only coordinator merges. Sources/deck canvases may prepare bounded additions. No repeated research without named missing evidence.

Core priorities: confirmed applicability when evidence allows; reviewed state/local interactions; humane language with exact receipts; truthful change/dates; complete reproducible submission. A compact unresolved answer is a safe fallback, not evidence that T2 or governing-law work is complete.

Stretch: Spanish only after core gates and deployment are ready, with reviewed translation; addedjurisdiction/live monitoring deferred. No fabricated facts or definitive answers to make cards look complete. No legal certification, numerical accuracy rate or full-challenge pass until corresponding evidence exists.
