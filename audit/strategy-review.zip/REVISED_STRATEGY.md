# Coordinator strategy — candidate for external review

Status: internal review candidate. Implementation paused; Claude critique pending. No promise of perfection. A model disagreement is a signal to inspect evidence, not a vote on legal truth.

## 1. Protect the working baseline
Keep existing source snapshots, API responses, output versions and logs. Record exact reviewed release, hashes, model, date and limitations. Retain canonical rules/lookups/changes contracts. Add the resident explanation as a separately validated presentation layer, not a replacement for legal records. No broad rerun simply to increase the percentage approved.

## 2. Correct claims before improving appearances
Separate reported internal checks from PDF acceptance. T2 currently establishes city-bound potential notification, not confirmed eligibility. Do not claim completed local-ban applicability. Treat 286 approved predicates as model-review outcomes, not 286 correct laws or a measured accuracy percentage. Preserve unknown legal dates, unavailable texts and source-integrity mismatch. Judge-facing metrics must identify fixture checks, offline checks, saved live-model results and observed browser checks separately.

## 3. Close answer-changing legal gaps
Audit the 24 unresolved predicates by rejection reason. Where a missing fact is genuine, compile a conservative expression with an explicit missing-fact reason; do not make dataset residential scope prove primary residence, owner type, detention/care exclusion or certificate date. Where the evidence chain is inadequate, remain source/status/review unresolved. Retrying is justified only by new evidence or a changed compiler approach that addresses a specific rejection.

Prioritize duplicate legal records and state/city precedence for rent caps and just cause. A smaller number is not sufficient to choose the governing cap: jurisdiction, coverage, statutory exclusions and effective dates must all be supported. Any precedence edge needs source IDs, exact support, reviewer result and a test where missing facts block certainty. Preserve secondary sources separately. If no safe resolution is possible within the submission window, the resident answer must explain the unresolved choice, and the submission must list it as a gap.

County geography remains distinct from county-law ingestion. Audit all 87 manifest records by captured, inaccessible, linked-only or superseded/versioned condition; document completeness by source, not rule count. Santa Ana is in corpus scope even though no supplied sample city is Santa Ana. No new jurisdiction or live-monitoring stretch work until core acceptance is addressed.

## 4. Make a resident answer with a claim ledger
Main question: What housing rules apply to my home? Show supplied address selection and the actual saved query date. Six category questions: How much can my rent rise? What rules govern eviction? How much can the deposit be? What application fees are allowed? What can a landlord check? What rules govern rent-setting software?

Each category contains a short answer and any condition that changes its meaning. One sentence is a preference, not a correctness requirement. Do not merge varied rules into a single yes/no status. A category may contain established protections alongside unresolved parts; say that explicitly. Omitted or unloaded law does not mean no protection.

Public reason classes: need property/tenancy fact; legal jurisdiction unresolved; source/status not verified; eligibility logic not reviewed; unresolved overlap/conflict; pending; not yet effective; failed change. Include the most useful supported next fact/question when known, but never promise that one additional fact will settle multiple unresolved issues.

Each material sentence has support IDs. Check my homework opens only its supporting receipts: exact quote, citation, source URL, retrieval date, query date, verified effective date/status, limits and conflict. Geography and property-data claims cite their own inputs, not a law that does not establish those facts. Source hash disagreement is available in the audit; answer-changing limitations are visible with the answer.

## 5. Validate translation separately
Generate explanations from frozen evidence and results, with an independent semantic review. Check subject, trigger, jurisdiction, threshold, dates, exemptions, operative status and lack of fabricated applicability. Mechanical support-ID existence alone does not establish semantic support. Reject unsupported summaries instead of polishing them. Useful translations remain conditional where evidence is conditional.

Regression cases: reviewed predicate but missing owner/CO; unreviewed predicate with complete sample data; uncertain city; multiple local/state caps; pending proposal; future enactment; failed ballot; mixed known/unknown category; source unavailable. Plain-language fallback is specific and short. Optional Spanish only after English passes, with the same evidence ledger and semantic checks.

## 6. Verify the real screen and release
Test actual 500-address saved data, date switching, scoped homework, keyboard/mobile, unknown reason classes and T1–T5 details. Existing fixture browser proof is useful but does not prove production data/browser deployment. Keep full details and audit accessible; remove raw engine prose from the initial resident view.

## 7. Deliver and demonstrate
Reconcile method note/deck/scripts with final evidence, not older counts. Create GitHub-ready review records; verify actual public repository permissions and deployed Render URL. Three <=60-second videos: human introduction; product story (answer, homework, change); technical walkthrough (automated extraction, geography, conservative eligibility, evidence and reproducibility). Complete HackOS and linked Google Form before9AM EDT Oct4; confirm receipts. Reserve at least90 minutes for recordings, uploads, permissions and recovery. External review is timeboxed to one critique and a documented response; no endless review loops.

## Completion standard
For every PDF/slide requirement: attach observed evidence or a named remaining gap. A release can be usable with honest unknowns; it cannot be called complete by renaming failed eligibility as notification success. No counselor certification, safety guarantee, evaluator score or measured legal accuracy is claimed without corresponding evidence.
