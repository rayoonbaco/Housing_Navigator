# Photographed slide observations
Coordinator and resident reviewer viewed the supplied photos. These are requirements/design cues, not production law answers.
- IMG_3059 / slide9: The law that protects a home should be readable by the people living in it; every answer traceable.
- IMG_3055 / slide6: Extract, Resolve, Apply, Explain, Track change. Explain includes plain language, quoted source and as-of.
- IMG_3054 / slide5: Compact address/context plus six short category answers with statuses. Illustrative example, not a legal result to copy.
- IMG_3056 / slide7: Unknown valid; mailing city differs from legal city; enacted differs from in effect; pending and struck measures are not current law; stricter governing rule.
- IMG_3057 / slide8:75 script points: extraction25/address20/citations15/change15;25demo:plain language10/responsible design10/scale5. Source/date, as-of, pending separation, unknown rather than guessing; no legal advice or evasion.
- IMG_3061:general judging technical depth, communication, innovation/creativity.
These weights are photographed presentation evidence, not an evaluator score assigned to this project. Full challenge PDF remains included separately.
