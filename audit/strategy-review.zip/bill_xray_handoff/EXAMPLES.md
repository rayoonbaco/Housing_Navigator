# Actual Bill X-Ray receipt examples

## TCJA — rate tables
**Plain statement:** For tax years 2018 through 2025, the bill replaces the individual rate tables with seven brackets ranging from 10% to 37%.

**Citation:** SEC. 11001 — MODIFICATION OF RATES — TCJA source lines 47-78

**Exact passage (excerpt):**
> Modifications for Taxable Years 2018 Through 2025... In the case of a taxable year beginning after December 31, 2017, and before January 1, 2026... Rate tables...

**Limit:** This fact does not say how any particular household's total tax changes.

---

## TCJA — SALT cap
**Plain statement:** For the temporary period, the bill caps the covered state-and-local-tax deduction at $10,000, or $5,000 for married taxpayers filing separately.

**Citation:** SEC. 11042 — LIMITATION ON DEDUCTION FOR STATE AND LOCAL, ETC — TCJA source lines 2093-2096

**Exact passage:**
> ...shall not exceed $10,000 ($5,000 in the case of a married individual filing a separate return)...

**Limit:** The section contains exceptions, including taxes connected with a trade or business or income-producing activity.

---

## CHIPS — loans vs appropriation
**Plain statement:** The law allows up to $6 billion of fiscal-year-2022 CHIPS funds to cover the cost of direct loans and loan guarantees supporting no more than $75 billion of loan principal.

**Citation:** SEC. 102(a)(2)(B) — DIRECT LOANS AND LOAN GUARANTEES — GovInfo · Public Law 117-167 · p. 8 · lines 417-428

**Exact passage:**
> The Secretary of Commerce may use ... up to $6,000,000,000 ... for the cost of direct loans and loan guarantees ... not to exceed $75,000,000,000 [in principal].

**Limit:** The $75 billion figure is a ceiling on gross loan principal, not a $75 billion appropriation or a statement of actual loans made.

---

## ACA — public promise evidence lane
**Plain statement:** President Obama publicly promised that people who liked their doctors and health plans would be able to keep them.

**Lane:** RHETORIC

**Source:** White House archive URL stored in the live receipt.

**Limit:** This is evidence of the public promise, not evidence that the statute guaranteed the promise or that later outcomes matched it.

This example matters because Bill X-Ray stores rhetoric, enacted law, implementation, official analysis, and observed outcomes as separate evidence lanes instead of blending them.
