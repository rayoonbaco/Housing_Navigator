# Bill X-Ray -> Housing Navigator Handoff

## Purpose
This package recovers the actual Bill X-Ray **CHECK MY HOMEWORK** method and adapts it for Housing Navigator without inventing any housing-law answer.

Bill X-Ray's public doctrine is: give the reader the human meaning first, but keep the evidentiary machinery directly underneath it. The public shell says **CHECK MY HOMEWORK** and opens a receipts drawer. The current repository README describes it as the single doorway to "receipts, source excerpts, limits, and provenance."

Repository inspected: `rayoonbaco/Bill_XRay_Next` (current public implementation through Pass 46.3).

---

# 1. Exact feature name, behavior, and reusable implementation

## Exact feature name
**CHECK MY HOMEWORK**

The drawer heading itself is **Check my homework** and the drawer eyebrow is **RECEIPTS**.

The public page places the feature after the human-readable essay. Its helper line is:

> See exactly what the column is standing on.

This is implemented, not proposed.

## How it works in Bill X-Ray
1. The reader sees the concise explanation and essay first.
2. The reader clicks **CHECK MY HOMEWORK**.
3. A right-side drawer opens over a dimmed page.
4. The drawer renders a list of receipt cards.
5. Each receipt presents:
   - a plain-language factual claim (`label`)
   - section / heading / source metadata
   - source links when present
   - one or more explicit limitations prefixed with **Limit:**
   - an expandable **Show source excerpt** control when an excerpt exists
6. The drawer can be closed by the X, clicking the scrim, or pressing Escape.

## Actual implementation files
The relevant live files are:

- `public/index.html` — button, drawer shell, labels, accessibility attributes
- `public/app.js` — `renderReceipt()`, open/close drawer behavior, evidence rendering
- `public/styles.css` — drawer / receipt / limit / excerpt presentation
- `public/data.js` — the real receipt objects and the story-to-fact mappings
- `docs/DOCTRINE.md` — truth, uncertainty, translation, and conflict rules
- `src/columnist.py` — human prose selection and paragraph-level support ledger
- `src/human_story_engine.py` — only court-cleared facts may enter the story; unresolved questions stay questions
- `src/truth_court.py` — `SUPPORTED_NARROWLY`, `QUESTION_ONLY`, and `HOLD` claim discipline
- `src/reality_stack.py` — evidence lanes, missing-lane policy, conflicting-source policy
- `src/teacher_gate.py` — release gate for source fidelity, traceability, human translation, semantic precision, synthesis, and restraint
- `SMOKE_TEST_PASS_45.py` — tested requirement that the new bill remain understandable without becoming false

Exact extracted UI code is included under `original_extracts/`.

---

# 2. Rules used to turn technical material into neighbor-level human prose

Two things exist here and should be distinguished.

## A. Implemented repository doctrine
These rules are explicitly encoded in the Bill X-Ray repository:

- "Translation means reconstructing what actually happened, not shortening statutory text."
- "Every material factual statement must be traceable to evidence."
- "If context is unresolved, say so. Never fill a semantic gap with confidence theater."
- "The final public work should read like gifted human editorial prose, not an AI dashboard."
- "A sentence that is clever but does not clarify is cut. A sentence that clarifies but cannot be proven is cut. A sentence that is accurate but still sounds like Congress is rewritten."
- "Do not force TRUE/FALSE when the honest answer is conditional, incomplete, or outside the four corners of the statute."
- "A missing evidence lane means not loaded, not nonexistent."
- "When reliable sources conflict, preserve the conflict and provenance. Do not average disagreement into fake certainty."

The `columnist.py` voice is explicitly:

> plainspoken, curious, dry when complexity earns it, nonpartisan, and more interested in revealing structure than displaying expertise.

Its selection doctrine is:

> Do not tell the reader everything the machine learned. Tell the one true story the evidence reveals.

The public prose is allowed to omit aggressively, but not distort the basic shape of the law.

## B. Conversation-level writing direction used during the project
The project work added a stronger human-language target that is not literally a named function in the repo: write for a normal person who is struggling to understand the issue, in language that sounds like **two neighbors talking**, while preserving citations, conditions, exceptions, dates, and uncertainty.

For Housing Navigator, turn that into this operational rule:

### Neighbor test
A housing answer should sound like one informed neighbor explaining the rule to another over the fence. It should not sound like a lawyer memo, a statute digest, or a chatbot.

### Accuracy test
Plain language is allowed to simplify vocabulary, not legal conditions.

The following must survive translation whenever they matter:
- who the rule covers
- what triggers it
- geography / jurisdiction
- property type
- owner / tenant status
- exemptions
- thresholds
- deadlines / effective dates
- procedural steps
- exceptions
- unresolved cross-references
- source conflicts
- uncertainty about applicability

### Preferred sentence shape
1. Start with the answer the person needs.
2. Add the condition that makes the answer true.
3. Add the exception or uncertainty that could change it.
4. Stop.
5. Put the legal machinery in **Check my homework**, not in the main answer.

Example pattern only — not a housing-law claim:

> "This rule appears to cover your situation **if** [condition]. The main exception we still need to check is [exception]."

Avoid:

> "Pursuant to subsection (b)(3)(ii), covered dwelling units shall..."

Also avoid false certainty:

> "Yes, this definitely applies to you."

unless the evidence actually establishes every applicability fact the answer depends on.

---

# 3. How a plain-language claim connects to evidence

Bill X-Ray uses two linked layers.

## Paragraph-level ledger
In `public/data.js`, each story paragraph has `support_fact_ids`.

That means the essay itself has a hidden ledger of which facts support each paragraph.

The Pass 45 teacher gate tests that every story paragraph names support IDs that exist in the receipt set.

## Receipt-level evidence object
A Bill X-Ray receipt can contain:

- `id` — fact identifier (present in newer data; some older receipts rely on positional / generated identity)
- `label` — the plain-language factual claim shown to the user
- `section`
- `heading`
- `source`
- `source_links` — optional live links
- `excerpt` — exact support shown under **Show source excerpt**
- `limits` — explicit statements of what the source does not establish
- `confidence` — present in some evidence objects

The UI does not bury limitations. `app.js` renders each one visibly as:

`Limit: ...`

The source excerpt is hidden until the user expands it.

## Important gap for Housing Navigator: dates
Bill X-Ray does **not** use one universal explicit `source_date` field in every receipt. Dates often live inside:
- the source itself,
- the section language,
- the source title,
- or later current-law metadata.

Housing Navigator should improve this contract rather than copy the gap.

For every housing receipt, add explicit fields:

- `effective_date`
- `source_published_date` (when known)
- `source_retrieved_date`
- `law_status_as_of`

Do not display a date that was not actually verified.

Recommended Housing receipt schema is included in `reusable/housing_receipt_schema.json`.

---

# 4. Missing information, conflicting sources, and unsupported claims

This is one of the strongest parts of Bill X-Ray.

## Missing information
Bill X-Ray's doctrine says:

> A missing evidence lane means not loaded, not nonexistent.

The ACA homework note says:

> The receipts keep the public promise, enacted law, agency implementation, official analysis, and observed outcomes in separate lanes. A missing lane stays missing.

For Housing Navigator, if the system lacks a needed applicability fact, say exactly that.

Examples of safe states:
- **Need one more fact** — e.g. owner occupancy is unknown
- **Source not loaded** — do not imply no rule exists
- **Current status not verified** — do not treat old law as current
- **Jurisdiction unresolved** — city/county/state layer still needs confirmation

## Conflicting sources
`docs/DOCTRINE.md` and `reality_stack.py` require the system to preserve source disagreement and provenance instead of averaging it into certainty.

Housing adaptation:
- show both authoritative sources
- identify whether they are different layers (statute vs regulation vs agency guidance vs court decision)
- explain the precise point of tension
- do not pick a winner unless source hierarchy or later law clearly resolves it

## Claims that cannot be supported
`truth_court.py` uses three useful states:

- **SUPPORTED_NARROWLY** — a limited factual statement is supported
- **QUESTION_ONLY** — the source supports asking the question, but not asserting the implied answer
- **HOLD** — evidence is missing, malformed, or too weak

Housing Navigator should adapt those internally, even if the public wording is friendlier:

- `SUPPORTED_NARROWLY` -> show the answer, with conditions
- `QUESTION_ONLY` -> "We found something worth checking, but not enough to say this applies"
- `HOLD` -> "I can't support an answer yet"

Do not manufacture a housing answer merely because the UI has six answer slots.

---

# 5. Actual Bill X-Ray examples

These are taken from the real `public/data.js` evidence objects.

## Example A — TCJA tax rates
### Simple statement
**For tax years 2018 through 2025, the bill replaces the individual rate tables with seven brackets ranging from 10% to 37%.**

### Evidence beneath it
- Section: `SEC. 11001`
- Heading: `MODIFICATION OF RATES`
- Source: `TCJA source lines 47-78`
- Exact excerpt begins:
  > "Modifications for Taxable Years 2018 Through 2025... In the case of a taxable year beginning after December 31, 2017, and before January 1, 2026..."
- Limit:
  > "This fact does not say how any particular household's total tax changes."

Why this is good: it separates a proved rate-table fact from a much broader household-impact claim.

## Example B — TCJA state-and-local-tax cap
### Simple statement
**For the temporary period, the bill caps the covered state-and-local-tax deduction at $10,000, or $5,000 for married taxpayers filing separately.**

### Evidence beneath it
- Section: `SEC. 11042`
- Heading: `LIMITATION ON DEDUCTION FOR STATE AND LOCAL, ETC`
- Source: `TCJA source lines 2093-2096`
- Exact excerpt:
  > "...shall not exceed $10,000 ($5,000 in the case of a married individual filing a separate return)..."
- Limit:
  > "The section contains exceptions, including taxes connected with a trade or business or income-producing activity."

Why this is good: the concise statement retains the filing-status distinction and the receipt retains the exception.

## Example C — CHIPS financing
### Simple statement
**The law allows up to $6 billion of fiscal-year-2022 CHIPS funds to cover the cost of direct loans and loan guarantees supporting no more than $75 billion of loan principal.**

### Evidence beneath it
- Section: `SEC. 102(a)(2)(B)`
- Heading: `DIRECT LOANS AND LOAN GUARANTEES`
- Source: `GovInfo · Public Law 117-167 · p. 8 · lines 417-428`
- Exact excerpt:
  > "The Secretary of Commerce may use ... up to $6,000,000,000 ... for the cost of direct loans and loan guarantees ... not to exceed $75,000,000,000 [in principal]."
- Limit:
  > "The $75 billion figure is a ceiling on gross loan principal, not a $75 billion appropriation or a statement of actual loans made."

Why this is good: the human sentence keeps the nouns attached to the numbers instead of collapsing everything into "government spent $75 billion."

## Example D — ACA public promise vs enacted mechanism
### Simple statement
**President Obama publicly promised that people who liked their doctors and health plans would be able to keep them.**

### Evidence beneath it
- Lane / section: `RHETORIC`
- Heading: `The White House`
- Source: White House archive URL stored directly in the receipt
- Limit:
  > "This is evidence of the public promise, not evidence that the statute guaranteed the promise or that later outcomes matched it."

A separate receipt then states the enacted-law mechanism, and another separate receipt covers CMS implementation. Bill X-Ray deliberately does not blend these evidence lanes into one claim.

---

# 6. Recommended Housing Navigator adaptation for six concise answers

## Public layout
For each of the six housing-law answers, use one compact answer block:

**Answer title**

1-3 short paragraphs in neighbor-level language.

**CHECK MY HOMEWORK ->**

When opened, show only the receipts supporting that answer.

Do not use one giant global drawer if the user is trying to understand six separate questions. The Bill X-Ray global drawer works for one essay; Housing Navigator should keep the same evidence philosophy but scope the receipts to the answer the person just read.

## Recommended answer contract
Each answer should have:

- `answer_id`
- `question`
- `plain_answer`
- `status` (`APPLIES`, `MAY_APPLY`, `DOES_NOT_APPLY`, `NEED_MORE_INFO`, `UNRESOLVED`)
- `why_in_one_sentence`
- `conditions[]`
- `exceptions[]`
- `unknowns[]`
- `support_fact_ids[]`
- `law_status_as_of`

Each receipt should have:

- `fact_id`
- `claim`
- `jurisdiction`
- `authority_type`
- `citation`
- `section`
- `source_title`
- `source_url`
- `effective_date`
- `source_published_date`
- `source_retrieved_date`
- `exact_excerpt`
- `limits[]`
- `conflicts[]`
- `status`

## Six-answer release gate
Before any answer appears publicly, test:

1. **Source fidelity** — every material claim has an authoritative receipt.
2. **Claim-to-receipt traceability** — every sentence that asserts law maps to support IDs.
3. **Human translation** — understandable to a non-lawyer on first read.
4. **Semantic precision** — dates, thresholds, property types, exceptions, and jurisdiction survive simplification.
5. **Applicability restraint** — no "this applies to your home" unless all required applicability facts are actually known.
6. **Conflict / uncertainty honesty** — unresolved or conflicting evidence remains visible.

## Recommended public wording
Use **Check my homework** exactly. It is warmer and less bureaucratic than "Legal authorities" or "Evidence panel," and it communicates humility rather than certainty theater.

For each answer, helper text can be:

> See the rule, the exact source language, and what could change this answer.

## Recommended drawer order
1. **What I'm relying on** — plain claim
2. **Where it comes from** — citation / section / source link
3. **Exact language** — expandable excerpt
4. **What this does NOT prove** — Bill X-Ray-style Limit
5. **Date / status** — effective date and current-law-as-of date
6. **What is still unknown** — only when needed
7. **Conflict** — only when present

---

# Implemented vs proposed

## Implemented and tested in Bill X-Ray
- CHECK MY HOMEWORK button and evidence drawer
- receipt cards with claim / source metadata / limits / expandable excerpts
- source links where populated
- story paragraphs carrying support fact IDs
- release test checking paragraph-to-receipt traceability
- explicit uncertainty / limits
- missing-lane doctrine
- conflict-preservation doctrine
- `SUPPORTED_NARROWLY`, `QUESTION_ONLY`, `HOLD` evidence discipline
- teacher-style A-grade gate for source fidelity, traceability, readability, semantic precision, synthesis, and restraint
- smoke tests proving a new law could be added without throwing away the evidence contract

## Proposed specifically for Housing Navigator
- one scoped Check My Homework drawer per one of the six housing answers
- explicit `effective_date`, `source_published_date`, `source_retrieved_date`, and `law_status_as_of` fields on every receipt
- public applicability statuses such as NEED_MORE_INFO / UNRESOLVED
- answer-level conflict display
- housing-specific jurisdiction / property / occupancy applicability fields

These housing recommendations are adaptations of Bill X-Ray's method. They are not claims that Bill X-Ray already implemented those exact fields.

---

# Bottom line for the Housing Navigator canvas
Do not copy Bill X-Ray's topic. Copy its **contract with the reader**:

**Meaning upstairs. Receipts downstairs.**

The person should get a concise, natural answer first. The evidence should be one click away. Conditions, dates, exceptions, uncertainty, and conflicts must survive the translation. Unsupported conclusions do not get prettier prose; they get blocked.
