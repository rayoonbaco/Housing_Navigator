# Start here

Open `HANDOFF.md` first.

For implementation:
- `original_extracts/` contains the Bill X-Ray homework UI pattern recovered from the actual repository.
- `reusable/` contains a Housing Navigator adaptation and a stricter receipt schema that adds explicit date/status fields.
- `HOUSING_NAVIGATOR_WRITING_PROMPT.md` can be pasted directly into the Housing Navigator canvas.
- `IMPLEMENTATION_STATUS.md` separates what Bill X-Ray actually implemented/tested from Housing-specific recommendations.
- `EXAMPLES.md` contains real Bill X-Ray claim/evidence examples.

No housing-law answer is asserted anywhere in this package.
