/* Exact relevant logic transcribed from Bill_XRay_Next/public/app.js */
function renderReceipt(r){
  const limits=(r.limits||[]).filter(Boolean).map(x=>`<p class="limit">Limit: ${esc(x)}</p>`).join('');
  const excerpt=r.excerpt?`<details><summary>Show source excerpt</summary><blockquote>${esc(r.excerpt)}</blockquote></details>`:'';
  const sourceLinks=r.source_links || (current==='sb1570' ? data.sb1570.source_links : []);
  const links=(sourceLinks||[]).map(x=>`<a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">${esc(x.label)}</a>`).join(' · ');
  return `<section class="receipt"><h3>${esc(r.label)}</h3><p class="receipt-meta">${esc(r.section)}${r.heading?' · '+esc(r.heading):''}${r.source?' · '+esc(r.source):''}</p>${links?`<p class="receipt-links">${links}</p>`:''}${limits}${excerpt}</section>`;
}

function openDrawer(){
  q('#homework').classList.add('open');
  q('#homework').setAttribute('aria-hidden','false');
  q('#homeworkButton').setAttribute('aria-expanded','true');
  q('#scrim').hidden=false;
}

function closeDrawer(){
  q('#homework').classList.remove('open');
  q('#homework').setAttribute('aria-hidden','true');
  q('#homeworkButton').setAttribute('aria-expanded','false');
  q('#scrim').hidden=true;
}
