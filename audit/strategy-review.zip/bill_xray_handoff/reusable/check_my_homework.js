/*
  Housing Navigator adaptation of Bill X-Ray's public/app.js receipt renderer.
  This is an adaptation, not a byte-for-byte copy of the original file.
*/
(function(){
  const esc=(s)=>String(s??'').replace(/[&<>\"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

  function renderReceipt(r){
    const limits=(r.limits||[]).filter(Boolean)
      .map(x=>`<p class="limit"><strong>Limit:</strong> ${esc(x)}</p>`).join('');
    const conflicts=(r.conflicts||[]).filter(Boolean)
      .map(x=>`<p class="conflict"><strong>Conflict:</strong> ${esc(x)}</p>`).join('');
    const excerpt=r.exact_excerpt
      ? `<details><summary>Show exact source passage</summary><blockquote>${esc(r.exact_excerpt)}</blockquote></details>`
      : '';
    const link=r.source_url
      ? `<p class="receipt-links"><a href="${esc(r.source_url)}" target="_blank" rel="noopener noreferrer">Open official source</a></p>`
      : '';
    const dates=[
      r.effective_date && `Effective: ${r.effective_date}`,
      r.law_status_as_of && `Current-law check: ${r.law_status_as_of}`,
      r.source_retrieved_date && `Retrieved: ${r.source_retrieved_date}`
    ].filter(Boolean).join(' · ');

    return `<section class="receipt">
      <h3>${esc(r.claim)}</h3>
      <p class="receipt-meta">${esc(r.citation||'')}${r.section?' · '+esc(r.section):''}${r.authority_type?' · '+esc(r.authority_type):''}</p>
      ${dates?`<p class="receipt-meta">${esc(dates)}</p>`:''}
      ${link}${limits}${conflicts}${excerpt}
    </section>`;
  }

  function openHomework(answer){
    const drawer=document.querySelector('#homework');
    const receipts=document.querySelector('#receipts');
    const note=document.querySelector('#homeworkNote');
    if(!drawer||!receipts) return;
    note.textContent='See the rule, the exact source language, and what could change this answer.';
    receipts.innerHTML=(answer.receipts||[]).map(renderReceipt).join('');
    drawer.classList.add('open');
    drawer.setAttribute('aria-hidden','false');
    document.body.classList.add('no-scroll');
  }

  function closeHomework(){
    const drawer=document.querySelector('#homework');
    if(!drawer) return;
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden','true');
    document.body.classList.remove('no-scroll');
  }

  window.HOUSING_HOMEWORK={renderReceipt,openHomework,closeHomework};
})();
