# Independent Claude review request
You are the external red team. Critique this strategy before implementation. Do not merely affirm it. Identify materially wrong outcomes and concrete adversarial examples. Distinguish source facts, model interpretations, code behavior and missing evidence. You cannot inspect files outside this supplied packet or verify current law by inference. This is product/engineering strategy review, not legal certification.

Return Markdown in these sections:
1. Verdict and five most consequential risks.
2. Challenge/slide coverage: missing core requirements versus justified unknowns versus stretch work.
3. Concrete counterexamples to the resident summary design and our current pass claims.
4. What to accept, reject or change in the internal reviewers' recommendations.
5. Revised order of work through9AM Eastern Oct4,2026, reserving90minutes for delivery. Do not spend all remaining time reviewing.
6. Testable acceptance gates for concise explanations, legal precedence, source fidelity, unknown reasons, date changes and actual browser behavior.
7. Claims to remove from the demo and honest replacements.
8. Unresolved questions that need source data or human action rather than another model vote.

Keep recommendations efficient and specific. Do not fabricate legal answers, dates, reviewer results or grader scores. Output is advice, not an instruction to execute changes. Current baseline and raw critiques follow.



---
# Packet file: CHALLENGE_TEXT.md
## PDF page 1
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
1
PROPOSED MIT AI HACKATHON CHALLENGE - 24 HOURS - PUBLIC DATA ONLY
Rental Housing Law Navigator
An AI system that reads public housing law and answers one question for any apartment address: which
rules apply here today, and how do the supplied change cases affect the answer?
How might AI turn thousands of pages of state and local housing law into accurate,
cited, address-level answers that renters, advocates, housing agencies and housing
providers can trust?
The problem is specific, real and getting harder
Rental housing in the United States is regulated in layers: state statutes, county rules and city ordinances, each with its own coverage
tests, effective dates and exemptions. The answer to what rules apply to an apartment depends on the exact address and the query
date.
Why it matters
What teams must handle
Layered rules
State and local rules can overlap, defer to one another or be superseded.
Address precision
A mailing city is not always the legal city. Jurisdiction resolution is part of the task.
Changing law
The supplied tests include effective-date changes, pending bills and a failed ballot question.
Who this helps
Renters
Advocates and agencies
Housing providers
Know which protections apply at their address.
See how rules cover buildings and what supplied
changes would affect.
Understand obligations before acting, especially
without legal staff.
The challenge in one line: In 24 hours, build a working system that extracts rules from a
provided corpus of real housing law, resolves sample addresses to the rules that apply
with citations, and reports the address sets affected by five supplied change cases.


## PDF page 2
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
2
WHAT TEAMS BUILD
From legal text to an address-level answer
Three required modules plus stretch goals. The starter pack lets teams spend the 24 hours on AI, workflow
design and responsible reasoning rather than data collection.
1. Extract
2. Resolve
3. Apply
4. Explain
5. Track
Turn statutes and
ordinances into structured
rule records.
Geocode an address and
build its state, county and city
stack.
Test coverage conditions
against building facts and
exemptions.
Return applicable rules with
plain-language explanations
and citations.
Run the five supplied change
cases and report affected
addresses.
Required modules
Module
Requirement
A - Rule extraction
Read each corpus document and output one structured record per rule. Extraction must be automated, not hand-coded.
Capture category, jurisdiction, requirement, coverage conditions, exemptions, effective date, status, penalty, citation and a
quoted span.
B - Address lookup
Resolve each address to its legal jurisdiction stack and report every applicable rule. If coverage depends on a missing fact,
report unknown rather than guessing.
C - Change tracking
Run the supplied change cases, list affected sample addresses and support an as-of-date query. No surprise document or
mid-event release is required.
Stretch goals
- Renter-facing plain-language view in English and Spanish.
- Confidence indicator and conflict flag for each answer.
- Extend to one new jurisdiction using the same extraction and coverage pipeline.
- Audit view showing the source, retrieval date, as-of date and reasoning boundary for each answer.


## PDF page 3
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
3
SCOPE FOR 24 HOURS
3 states - 10 cities - 6 rule categories
Small enough to finish, varied enough to be hard. The jurisdictions cover state-only rules, layered local rules
and recent or failed changes.
State
Cities in scope
Why it is included
California
Los Angeles, San Francisco, San Diego,
Berkeley, Santa Ana
Dense layering: statewide rent and just-cause rules, local rent control and
algorithmic-pricing rules.
New Jersey
Jersey City, Hoboken, Newark
City-by-city rent control, statewide eviction and screening rules, and a statewide
algorithmic-pricing law with a future effective date.
Massachusetts
Boston, Cambridge
State law bars local rent control; pending algorithmic-pricing bills and a failed ballot
question test negative findings.
Rule categories
Category
What to capture
Rent increase limits
Cap formula, covered buildings, exemptions and local-versus-state precedence.
Just-cause eviction
Allowed causes, notice, relocation assistance and coverage.
Security deposits
Maximum, exceptions and effective date.
Application and screening fees
Fee caps, allowed upfront charges, receipts and refunds.
Screening restrictions
Criminal-history and income-source limits and timing rules.
Algorithmic rent-setting
Covered software, prohibited conduct, penalties and effective date.
The corpus covers three states and ten cities. It has not been reviewed by counsel and is for prototype challenge scoping only.


## PDF page 4
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
4
TEST CASES AND STARTER PACK
Deterministic change cases, packaged data
Teams work from the same fixed corpus and address sample. Change tracking is evaluated against five
explicit cases, all defined at kickoff.
Test
What a correct system does
T1 - CA AB 325 / SB 763
Reports not yet effective on 2025-12-31 and applies on 2026-01-02 for California addresses.
T2 - Hoboken and Jersey City local bans
Applies each local ban only inside its own city limits, not in Newark.
T3 - NJ FAIR Act
Reports not yet effective on 2026-10-01, applies on 2027-07-02 and flags possible conflicts with local bans.
T4 - MA S.2983 and H.5222
Reports both bills as pending and lists the Massachusetts addresses they would affect if enacted.
T5 - MA rent-control ballot question
Reports no rent cap for Boston or Cambridge because the question was struck; affected set is empty.
Starter pack provided to teams
Item
Contents
Format
Law corpus
87 source documents with URL and retrieval date; links for sources without supplied text.
Text + CSV
Sample addresses
About 500 multifamily properties in nine cities from public assessor data. No owner names.
CSV
Rule schema
Required fields for every rule record and a worked example.
JSON Schema
Change tests
The five explicit cases above and their test definitions.
JSON


## PDF page 5
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
5
DATA AND RESPONSIBLE DESIGN
Build for transparency, not legal verdicts
The system should make housing law easier to see and understand without pretending to be a lawyer or
helping anyone work around the rules.
Public sources teams may use
Source
Use it for
State codes and municipal codes
Official statute and ordinance text.
LegiScan and Open States
Bill status, sponsors, events and text where available.
Census Geocoder and TIGER/Line
Address-to-jurisdiction resolution and boundary checks.
Public parcel data
Building facts such as year built, units and use code.
Local program lookups
Spot-checks for rent-control coverage; not a replacement for the corpus.
The solution should
The solution must not
Cite source text and retrieval date; show an as-of date; separate enacted
from pending law; say unknown when facts are missing; flag conflicts for
human review; keep an audit log.
Present output as legal advice or a compliance certification; invent rules or
citations; use non-public data; or scrape sites in violation of their terms.
A practical 24-hour plan
Time
Focus
Hours 0-1
Kickoff, starter-pack walkthrough and mentor introductions.
Hours 1-6
Rule extraction against the supplied corpus and starter-pack self-check.
Hours 6-11
Geocoding, jurisdiction stacks and coverage logic.
Hours 11-18
Address lookup, citations, plain-language view and deterministic change cases.
Hours 18-23
Validation run, fixes and demo preparation.
Hours 23-24
Demos and judging.


## PDF page 6
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
6
BUILD AND SUBMIT
Make every answer traceable
The participant guide contains the full detail. These are the build expectations and submission materials to
prepare for the event.
Build expectations
Submission package
Build Modules A, B and C from the supplied corpus and address sample.
Extraction must be automated. Unknown is valid when facts are missing.
Use public data only, respect source terms and label every interface not
legal advice.
rules.json: structured rules with citations and quoted source text; lookups.json:
results for all sample addresses; changes.json: affected addresses and conflict
flags for each supplied test; live demo and one-page method note.
A strong submission
- Shows the source document, quoted span, retrieval date and as-of date for every answer.
- Separates enacted, pending, not-yet-effective and failed changes.
- Reports unknown when a required fact is missing and flags conflicts for human review.
- Keeps a simple audit log so another person can reproduce the result.
The intended outcome: show that responsible AI can make housing law visible at the
level that matters - a single address - so renters know their rights, providers know their
obligations and every answer is traceable to its source.



---
# Packet file: SLIDE_REQUIREMENTS.md
# Photographed slide observations
Coordinator and resident reviewer viewed the supplied photos. These are requirements/design cues, not production law answers.
- IMG_3059 / slide9: The law that protects a home should be readable by the people living in it; every answer traceable.
- IMG_3055 / slide6: Extract, Resolve, Apply, Explain, Track change. Explain includes plain language, quoted source and as-of.
- IMG_3054 / slide5: Compact address/context plus six short category answers with statuses. Illustrative example, not a legal result to copy.
- IMG_3056 / slide7: Unknown valid; mailing city differs from legal city; enacted differs from in effect; pending and struck measures are not current law; stricter governing rule.
- IMG_3057 / slide8:75 script points: extraction25/address20/citations15/change15;25demo:plain language10/responsible design10/scale5. Source/date, as-of, pending separation, unknown rather than guessing; no legal advice or evasion.
- IMG_3061:general judging technical depth, communication, innovation/creativity.
These weights are photographed presentation evidence, not an evaluator score assigned to this project. Full challenge PDF remains included separately.



---
# Packet file: BASELINE.md
# Review baseline — 2026-10-04 UTC

Implementation is paused at the user's request. This review is a strategy critique, not legal certification or an organizer scoring run.

Current saved run: engine-2.3 / 20261004T023146-7b62feda. 310 rules; 286 model-reviewed coverage predicates; 24 unresolved; 500 sample addresses; 480 matched legal cities/counties; 20 unresolved. Forty offline engine tests passed in the user's Windows run. Coordinator previously reproduced four 500-address snapshots and preserved predicate equality; those prior checks are not newly rerun in this strategy pass.

Reported T1–T5 checks pass, with material qualifications: T2 has 88 potential city-bound notifications, zero confirmed eligible addresses; its pass does not establish the PDF's full local-applicability requirement. T1/T3 retain unknown rules alongside established affected sets. T4 is hypothetical pending legislation. T5 concerns the failed ballot question, not proof that Massachusetts has no other housing protections.

Existing UI is a saved-run browser viewer, not live legal monitoring or arbitrary-date evaluation. User screenshots show loaded address list, county metadata and rule cards. Drawer, change tab, audit tab and deployed release have not been verified on the user's current build in this review.

Known deficiencies: cross-source stricter-rule precedence and duplicate consolidation unfinished; source-byte organizer hashes differ from all 54 captured snapshots; D056 missing despite capture=yes; 33 link-only access gaps; exact Jersey City operative dates/current consolidated amendment text unresolved; official final court-hosted opinion inaccessible (third-party court-opinion hosting disclosed); county metadata does not prove county-law coverage. Missing owner/certificate/tenant facts may legitimately prevent an answer. Model review is not measured legal accuracy.

Bill X-ray handoff supplied by user: CHECK MY HOMEWORK; sentence/paragraph support IDs, receipts, expandable source excerpts and visible limitations. Repository behavior is described by the supplying canvas and code extracts; coordinating canvas has inspected the supplied handoff, not independently audited its live repository. Housing-specific schema and six-answer pattern are proposals, not implemented here.

Proposed direction for red-team challenge: six concise resident questions; date and legal geography; claim-specific receipts; actual unknown reason categories; retain all engine records behind details; prevent a summarized category from selecting a governing rule without reviewed precedence; publish unsupported answers as unresolved. No fixed universal one-sentence limit if it hides a decisive condition.

Submission requirements observed in user HackOS screenshots: valid GitHub link, team photo <=10MB, three separate <=60-second intro/demo/technical videos, HackOS plus linked Google Form. Public deployment and final submission remain undone. Deadline 9AM Eastern Oct4 (grace to9:15 observed; plan before9). Presentation source package describes an older release and must be reconciled.



---
# Packet file: CURRENT_RUN_REPORT.json
{
  "version": "engine-2.3",
  "as_of": "2026-10-01",
  "rules": 310,
  "coverage_approved": 286,
  "coverage_unresolved": 24,
  "addresses": 500,
  "genuine_api_calls": 10,
  "estimated_usd": 1.76364,
  "change_tests": [
    {
      "test_id": "T1",
      "status": "pass",
      "affected": 250,
      "unknown": 250,
      "confirmed_affected": 250,
      "potentially_affected": 0,
      "rule_ids": [
        "HN-SUP-P001-001",
        "HN-SUP-P001-002",
        "HN-SUP-P001-003",
        "HN-SUP-P002-001",
        "HN-SUP-P002-002",
        "HN-SUP-P002-003"
      ],
      "scope": "Actual extraction/coverage results; expected case is an assertion, never substituted as an output."
    },
    {
      "test_id": "T2",
      "status": "pass",
      "affected": 88,
      "unknown": 93,
      "confirmed_affected": 0,
      "potentially_affected": 88,
      "rule_ids": [
        "HN-SUP-P005-002",
        "HN-SUP-V4S002-001",
        "HN-SUP-V4S002-002"
      ],
      "scope": "Actual extraction/coverage results; expected case is an assertion, never substituted as an output."
    },
    {
      "test_id": "T3",
      "status": "pass",
      "affected": 140,
      "unknown": 140,
      "confirmed_affected": 140,
      "potentially_affected": 0,
      "rule_ids": [
        "HN-D069-001-001",
        "HN-D069-001-002",
        "HN-D069-001-003",
        "HN-D069-001-004",
        "HN-D069-001-005"
      ],
      "scope": "Actual extraction/coverage results; expected case is an assertion, never substituted as an output."
    },
    {
      "test_id": "T4",
      "status": "pass",
      "affected": 110,
      "unknown": 0,
      "confirmed_affected": 110,
      "potentially_affected": 0,
      "rule_ids": [
        "HN-SUP-S018-001",
        "HN-SUP-S019-001",
        "HN-SUP-S019-002",
        "HN-SUP-S019-004"
      ],
      "scope": "Actual extraction/coverage results; expected case is an assertion, never substituted as an output."
    },
    {
      "test_id": "T5",
      "status": "pass",
      "affected": 0,
      "unknown": 0,
      "confirmed_affected": 0,
      "potentially_affected": 0,
      "rule_ids": [
        "HN-SUP-S024-001"
      ],
      "scope": "Actual extraction/coverage results; expected case is an assertion, never substituted as an output."
    }
  ],
  "errors": [],
  "limitations": [
    "Preliminary model-reviewed output; not legal advice or counsel certification.",
    "Organizer source-byte manifest mismatch unresolved.",
    "20 legal cities unknown. Missing owner/certificate/tenant facts preserved.",
    "Supplemental provenance distinguishes raw official/publisher downloads from browser transcriptions and third-party hosting.",
    "No reviewed cross-source stricter-rule supersession or duplicate consolidation yet.",
    "T2 potential impact is a legal-place change-notification dependency, not confirmed eligibility; individual missing facts stay unknown.",
    "County is recovered geography metadata; supplied rule schema has state/city only.",
    "Court opinion is third-party hosted; direct official final IP25-21 endpoint remains unavailable.",
    "Historical/future snapshots conservative where full temporal validity is not established."
  ]
}


---
# Packet file: internal_reviews/evidence.md
# Internal red team — evidence, applicability and claims

Review date: 2026-10-04 UTC. Reviewer: independent internal evidence-review agent. This is an engineering critique of saved files, not counsel review or legal certification. No external API calls were made, no source access was attempted, and no engine or application files were edited.

## Material reviewed and checks actually performed

- Challenge PDF: `challenge/participant-final-no-hour16/mit-rental-housing-law-navigator-challenge-v5-participant-no-scoring-no-hour16.pdf`, all six pages converted to text and read.
- Latest saved return: `latest-four/engine-v2_3/20261004T023146-7b62feda`, including report, rules, coverage, provenance, jurisdictions, lookups and the three latest coverage rejections.
- Evaluator and change-test implementation: `deliverable/Housing_Engine_v2_3/evaluate.py` and `run_next.py`.
- Re-ran the existing offline suite with `python3 -X utf8 -m unittest -q`: **40 tests passed**. These are mocked/offline regression checks, not a new live legal review.
- Recomputed all 500 address results from rules, saved predicates and saved geographies at each of four supplied snapshots; each output matched its saved lookup file exactly. Each snapshot contains 33,284 returned rule-address records.
- Independently counted 310 unique rule IDs, six categories, 286 saved coverage predicates, 500 addresses, 480 county/place matches and 20 unresolved legal cities. Default-date row totals: 22,650 unknown, 9,215 applies, 979 not-yet-effective, 440 pending.
- Saved rules have nonempty URLs and quoted spans, but this review did **not** substantively inspect or independently verify every quote and legal paraphrase. 99 records have a non-null effective-date field; this is not a certification of their precision or correctness.

## Overall judgment

The saved pipeline has useful deterministic reproducibility and deliberately conservative safeguards. It is not yet equivalent to a complete address-level answer to the challenge. The priority is to resolve the difference between a transparent set of extracted records and a usable statement about the governing law. A larger number of model calls or more reviewed predicates alone does not resolve this difference.

There are two separate goals: trustworthy resident answers and the challenge's deterministic change assertions. Their evidence must remain separate. Unknown is explicitly allowed by the PDF when facts are missing; unknown due to failed evidence/compilation is a different limitation. Neither should be disguised by a concise design.

## Prioritized findings

### P0 — “5/5” is narrower than the PDF's T2 statement

The PDF page 4 says T2 applies each local ban only within its own city, excluding Newark. `run_next.py::changes` now includes unknown records in the affected set when a resolved legal city matches a selected ban. Its pass assertion checks that this notification-dependency set equals resolved Hoboken/Jersey City addresses; it does not require confirmed application. Latest report: T2 passes with **88 potentially affected, zero confirmed affected, 93 unknown**. The 93 include unresolved-boundary candidates; the 88 do not.

This is a defensible potential notification workflow, and the notes disclose it. It is not sufficient support for “all five legal applicability tests pass.” A judge could reasonably view it as moving the acceptance criterion. Preserve the existing receipt, but name its scope as a boundary/notification check and show a separate eligibility assessment. Missing property facts remain unknown rather than being invented to make the PDF assertion green.

**Gate:** In documentation, UI and video, any 5/5 statement must identify the scoped checks. T2 must visibly retain potential/confirmed counts and why eligibility is unknown. Do not change rules or facts merely to match expected address counts. A targeted predicate repair must address primary-residence intent and excluded facilities, and carry the required owner/agent exemption evidence, then pass independent review without optimistic dataset-label inference.

### P0 — No cross-source precedence means no single governing rent-cap answer yet

PDF pages 1 and 3 explicitly require handling overlap, supersession and local-versus-state precedence. The latest report explicitly says no reviewed stricter-rule supersession or duplicate consolidation. All 310 `overrides` fields are empty. `lookup` evaluates each record independently; it has no stage applying overrides or comparing governing caps. Merely returning local and state statements together cannot tell the reader which governs.

**Gate:** Before a category summary chooses one cap or suppresses one rule, establish an evidence-backed relationship using complete coverage, dates and any statutory savings/preemption language. Test a covered local building, a state-only building, an exempt building and an unknown building. If unresolved, show the competing conditional statements and say the governing limit needs verification. Do not select the numeric minimum automatically: exceptions, property coverage and authority determine which comparison is valid.

### P0 — Plain language must not convert conditional duties into promises

Existing `lookup` appends a caveat for applies results: the cited requirement still governs its transaction/event conditions. Some returned rules describe a court or agency duty, not a protection exercisable by every resident. The evaluator treats dataset apartment scope as limited contextual evidence, and lacks owner, tenancy and transaction fields. Those limits matter when condensing 121 eviction-category records or 60 deposit-category records into six resident answers.

**Gate:** Build claim-level prose linked to rule IDs and supporting spans. Preserve actor, action, trigger, building/tenant prerequisites, date and exceptions. A broad paragraph containing several legal claims needs several evidence links, not one source link that only supports its first sentence. A plain claim must not imply a violation happened merely because a conditional duty exists. The “Check my homework” expansion must reveal source URL, exact passage, retrieval and query dates, plus the facts used and the facts still missing.

### P1 — Evidence and coverage states need separate names

286 independently model-reviewed predicates do not mean 286 universally applicable protections. A predicate containing explicit unknown nodes may be correctly reviewed and still produce unknown. Three new targets failed review because dataset residential scope does not prove primary-residence intent or exclude care/detention uses. Another rejection also identifies an exemption copied from a rule record without the appropriate definition evidence. These are useful failures, not successes to erase.

The current final string “Coverage compilation did not pass independent review” conflates missing/rejected/uncertain compilation. Conversely, an unknown node may describe a permanently missing property fact. UI copy “we need one more detail” is justified only if that specific detail can actually resolve the relevant tree and the legal evidence is sound.

**Gate:** Distinguish (a) unverified legal source or compilation, (b) missing property/tenant facts, (c) unresolved geography, (d) unresolved legal relationship, (e) unknown date. Give the resident a feasible next question only for (b), without asking for sensitive unnecessary details. Asking a tenant's age or disability is not a default substitute for unresolved evidence.

### P1 — Temporal validity and conflict tests are incomplete

`date_status` permits an effective start date but no repeal/end validity interval. Without a precise start it allows in-force status only at the default 2026-10-01 snapshot; other dates become unknown. That conservatism is preferable to fabrication, but “as of any date” is not currently delivered. A start date alone is insufficient if the rule was later amended/repealed. Jersey City adopted amendments do not establish a publication-based exact operative date.

For T1 and T3, current acceptance requires at least one applies record after and at least one not-yet-effective before for each state address; it does not assert every selected rule's transition. Both runs can have confirmed and unknown simultaneously (T1 250/250; T3 140/140). For T4, the `confirmed_affected` field merely duplicates a hypothetical pending set: 110 are not confirmed present protections. T3 potential conflict flags include uncertain local applicability; they are not adjudicated invalidity or preemption.

**Gate:** Record per-rule start/status assertions and separately report complete versus partial transition evidence. Label T4 as hypothetical, including any count field displayed. For conflict summaries cite both competing rules and the unresolved interaction. Keep historical/future uncertainty visible; do not extrapolate default snapshots.

### P1 — Source coverage and provenance need an honest denominator

The supplied inventory is 87 sources, with 54 captured texts; D056's claimed capture is absent, and 33 link-only sources require access review. Latest rules reference 47 distinct `source_doc_id` values including supplements; that is not a document-read completeness metric. A document can produce zero accepted records, be out of scope, be inaccessible or fail validation; these cases require distinct ledger outcomes.

295 latest rule-level provenance records contain `manifest_hash_match: false`. Those include repeated rules from shared files, not 295 different failed documents. Pinning bundled text and validating local quote substrings establishes repeatability of that snapshot; it does not explain the organizer-byte mismatch or certify original-source integrity. Some supplements are browser transcriptions, while other captures are retained official bytes or third-party hosted court text. Do not flatten these evidence classes.

**Gate:** Produce a source ledger for all 87 plus supplements: access/capture type, extraction outcome, zero-rule reason, accepted/rejected counts, snapshot hash and original-manifest status. Accept new sources only through existing automated extraction and evidence review. Do not repeat broad acquisition if a rejected scope predicate only needs an explicit unknown and correctly linked definition.

### P1 — County and penalty expectations are only partially represented

PDF page 2 expects a state/county/city stack; supplied schema supports only state/city levels. 480 county names/GEOIDs are present from saved Census geography. This satisfies part of resolve but not county-law coverage. There must be an explicit source/schema interpretation, not an invented county rule or an assertion that no county rules exist.

PDF Module A requests penalty capture. There is no dedicated `penalty` field in any of the 310 saved records. Penalties may be represented in prose or separate extracted rules, so field absence alone does not prove missing penalty evidence. However a judge cannot easily verify structured penalty completeness.

**Gate:** Map the PDF's penalty expectation to actual schema-compatible representation with samples; disclose any unavailable fields. Document county geography versus corpus law scope. Do not silently extend the required schema in a way that invalidates submission outputs.

## Recommended efficient sequence after strategy approval

1. Freeze and hash this baseline; retain its original scoped receipts. Create an acceptance matrix in which every claimed pass has an evidence path and scope.
2. Review the high-impact category-summary contract before writing UI: one claim can cite several records, and multiple claims must keep separate evidence maps. Bill X-ray's expansion pattern is appropriate if adapted to legal prerequisites and uncertainty.
3. Repair only targeted eligibility compiler errors using already-held evidence and explicit unknown nodes. A reviewed unknown predicate is a legitimate outcome; it will not make all affected residents confirmed.
4. Establish or honestly defer precedence for the rent-cap examples used in the demonstration. Choose examples based on actual verified outputs, not on theatrical convenience or expected counts.
5. Run adversarial resident-answer checks for uncertainty, future/pending law, conflicting rules and boundary errors. Record each check's fixture/live/saved-data scope. Independent models may assess interpretation, but they do not replace source validation.
6. Update the method note and videos to the actual release. Exclude claims of exhaustive coverage, perfect legal accuracy, counsel review, production monitoring or universal dates unless those abilities have been demonstrated.

## Strategy critique

The proposed human-first view is the right next product direction. It should proceed only after the review defines what information may be condensed and what qualifications cannot disappear. “Six short answers” is a presentation target, not an acceptance criterion that every category must always resolve to one definitive sentence. A compassionate answer can be short while honestly saying, “This rule may protect you; we cannot confirm whether your building qualifies.” That wording still requires evidence for the rule and a precise explanation of the unknown.

A second-model critique can expose blind spots and deserves documentation. It is not statistical independence if both models inspect the same incomplete source context or anchor on the desired outcome. Send it the challenge text, actual scoped report, relevant code/receipts and unresolved evidence—not just our polished strategy. Ask it to find a concrete counterexample and a testable repair. Preserve its raw response, model/version and timestamp, then record which proposals we accept, reject or defer and why. Never describe model consensus as legal verification.



---
# Packet file: internal_reviews/resident.md
# Independent red-team review: resident experience and claim-level evidence

Review date: 2026-10-04 UTC. Scope: inspect actual saved UI code/data, the uploaded Bill X-Ray handoff, and five user-supplied slide photographs. No application code or production records changed. This is a strategy/code inspection, not a resident study or a new browser test.

## Verdict

Keep the evidence engine and audit viewer. Add a resident-first view whose primary unit is a practical question and a supported answer, rather than a rule record. Do not implement this as merely renaming Unknown and trimming explanation strings: that would hide distinct uncertainty causes and could select the wrong controlling law.

The proposed direction is sound, but needs three hard constraints: (1) claim-to-source validation including material exceptions, (2) reviewed consolidation/precedence before publishing a category conclusion, and (3) explicit distinction between missing resident facts and missing/unreviewed law evidence. A red team and another model can improve the strategy; neither establishes legal truth or perfection.

## Direct evidence inspected

- `upload/03-IMG_3059.png` (slide 9/9): home-protection law must be readable to its residents; every answer traceable to its source.
- `upload/06-IMG_3055.png` (slide 6/9): Extract -> Resolve -> Apply -> Explain -> Track change. Explain explicitly includes plain language, quoted source, and as-of date. Apply includes year built, unit counts and exemptions. These are system duties, not five chores for a resident.
- `upload/07-IMG_3054.png` (slide 5/9): illustrative compact address/context panel plus six concise category answers and statuses, including a state-cap supersession example. Its footnote says illustrative lookup, as of Oct 1, 2026. These are layout/behavior requirements, not verified production answers to copy.
- `upload/05-IMG_3056.png` (slide 7/9): missing year built, mailing city != legal city, enacted != in effect, pending != law, struck != law, stricter rule wins. A condensed screen must retain these distinctions.
- `upload/04-IMG_3057.png` (slide 8/9): 75 script-scored points (extraction 25, address coverage 20, citations 15, changes 15); 25 demo points (plain language 10, responsible design 10, scale 5). Transparency requires source/date for every rule, as-of, pending separate, unknown instead of guessing; no legal advice or evasion guidance.
- `review/bill-xray/Bill_XRay_Housing_Handoff/HANDOFF.md`, writing prompt, implementation status and examples: supported meaning first, claim receipts below, missing evidence not nonexistent law; paragraph support IDs and scoped Housing drawers proposed.
- Current `integration/release-candidate/ui/index.html`, `app.js`, `data/lookups.json` and reusable Bill X-Ray renderer/schema sample.

## Findings and priorities

| Priority | Finding | Evidence | Required strategy change |
|---|---|---|---|
| P0 | Unknown is falsely described as always missing property facts | `index.html` status legend says "needed property facts are missing"; saved `lookups.json` has Unknown with "Coverage compilation did not pass independent review" and incomplete legal exceptions | Introduce internal structured reason categories; display "We need a detail about your home" only for actual missing facts. Display "We have not verified this answer yet" for review failures and "We could not confirm the city's rules" for geography. |
| P0 | One category can have many rules, distinct conditions, dates, and authorities | `renderCategory()` renders every rule; A0001 has 73 saved results, including multiple near-overlapping screening, deposit and rent rules | A category summary needs its own supported claim ledger and reviewed selection/precedence. Never choose the first rule, highest confidence, any Applies, or the lowest numerical cap without checking same scope, date and exceptions. |
| P0 | Condensation may convert a rule about a conditional event into a claim about the home | Saved explanations distinguish property scope, screening events, tenant disability/animal facts and owner exceptions | Separate "what the rule says if this happens" from "what we know about this home." Do not infer that eviction, denial, rent increase, deposit request or tenant characteristic occurred. |
| P0 | Missing results cannot mean no protection | UI currently correctly warns empty category != no restriction; Bill X-Ray doctrine matches | Preserve the distinction in short prose. Do not produce DOES_NOT_APPLY or "No protection" from omitted/empty output. No category answer is a certification of full legal coverage. |
| P1 | Main screen exposes machinery before the answer | Current hero describes "supplied housing rules the engine returned"; address panels show IDs, dataset, benchmark, vintage, GEOIDs; each rule shows internal IDs and full engine explanation | Main view: address, date, brief location confirmation, six practical question cards. Keep original postal and matched geography provenance in an expandable address-details area and audits separate. |
| P1 | Source status and personal applicability can be blended in friendly language | Current UI has two separate badges per rule; handoff recommends answer-level statuses | Preserve two dimensions internally. Public future/pending wording must say when/if a change could matter; no green protection badge for a pending bill or a future statute today. |
| P1 | Quoted source alone is not enough to substantiate simplification | Handoff proposes support IDs; current UI simply displays rule.quote plus reviewer notes | For each material sentence map exact supporting spans, rule IDs and limitations; independently check semantic entailment, date, scope, numeric thresholds, actor and trigger. Presence of IDs is a structural check, not proof of meaning. |
| P1 | Broad claims of browser/readability verification would overstate this review | Existing upstream fixture browser checks are not a test of new prose or current production summary | After implementation run actual-data browser tests and a timed human comprehension check. Label fixture versus production, structural versus semantic, and model review versus actual user evidence separately. |

## Refined resident strategy

### Main screen contract

Lead with "What housing rules apply to my home?" and choose a supplied address and evaluated date. Avoid "Any address" unless real arbitrary-address resolution and evaluation are implemented. Use six practical questions: rent increases, eviction, deposit, application/screening fees, screening protections and rent-setting software. Each card should have one short main answer, at most one short qualification needed to interpret it, a visible date/status, and **Check my homework**. This is six topic answers, not a promise that each topic has exactly one governing legal rule.

Good prose structure: practical supported meaning -> decisive condition -> unresolved fact/exception or date. Prefer 20-45 words as an editorial target, not a forced limit when an exception would be lost. If multiple rules cannot be safely condensed, say so simply and expand related rules. Do not bury a condition that changes applicability solely inside a citation drawer.

Supported generic uncertainty copy (not housing-law conclusions):
- Missing fact: "We need to know [specific fact] before we can tell whether this rule covers your home."
- Unresolved law review: "We found a rule about this, but we have not verified enough to give you an answer yet."
- Conflict: "Two rules may matter here. We have not confirmed which one controls."
- Empty source coverage: "We do not have a verified answer for this topic in the sources checked."
- Future/pending: show actual verified date or pending status; do not fabricate one from retrieval date.

### Claim and answer contracts

Additive derived answer artifacts should preserve all original engine outputs and their hashes. Each answer should store address ID, query as-of, topic, ordered supported claims, status reasons, source-rule IDs, controlling-rule decision and grounds, applicable conditions/exceptions, unresolved facts, and citations. Include run ID/model/prompt provenance when AI writes or reviews prose.

Each material claim maps to one or more exact evidence spans and supporting rule IDs. A sentence containing multiple factual assertions either maps each assertion separately or is split. A category headline like "Your deposit is capped" is itself a claim and must be validated. Statements about known property facts map to their data provenance, rather than a legal citation. No assertion of a specific outcome from a source that only establishes authority or a possible remedy.

**Check my homework** must be scoped to this card's claims. Show claim -> legal citation/source link -> exact expandable span -> scope/exception limits -> verified effective/as-of/retrieval dates -> conflicting authority if relevant. Missing dates remain "not verified," never a made-up current-law check. Hash mismatch/integrity gaps remain accessible with clear authority labels. Do not label secondary guidance or mirrored court material "official source" automatically.

Ask the highest-value missing fact only after a reviewed predicate establishes that answering it can change eligibility. Do not collect sensitive household facts merely to make the prototype look complete. User-entered facts are unverified scenario inputs, separated from assessor/Census facts and public benchmark outputs. Keep sample evaluation reproducible.

### Consolidation before certainty

Duplicate summaries can be combined only when their law, scope and dates match. A local stricter-rule conclusion needs reviewed evidence of interaction/authority plus established property coverage, not the slide's illustrative example. Keep distinct landlord duties, tenant protections and government implementation duties separate. A statewide proposal or failed ballot question may appear in a changes section but must not become a current protection. Potential notifications remain potential, not personal entitlement.

## Reusable handoff cautions

1. `reusable/housing_receipt_schema.json` is a sample object, not a machine-enforceable JSON Schema. It lacks formal required/type/enum constraints; build a real validated contract before trusting it.
2. `reusable/check_my_homework.js` escapes text but does not restrict source URL protocols. Do not replace the existing `safeUrl()` HTTP(S) guard with that renderer. It also labels every link "official source" regardless of authority type, and needs focus handling/keyboard verification before adoption.
3. The adapted renderer expects receipt `law_status_as_of`, whereas the sample stores it at answer level; establish explicit inheritance or matching validation.
4. Bill X-Ray examples include ellipses and bracketed editorial additions in passages labeled exact. They illustrate reasoning but must not be imported as exact statutory evidence; current Housing exact-span policy should remain strict.
5. Claimed tests of Bill X-Ray's original repository are reported by the handoff. This review did not independently rerun those tests or verify the whole remote repository. Housing recommendations are proposed, not implemented features.

## Release tests to require

- Structural gate: every claim and referenced receipt resolves; source span is exact; authority/date/status fields valid; unsupported claim blocks publication.
- Semantic review: wrong actor, omitted exemption, wrong number/date, pending-as-law, ambiguous conflict, procedural outcome overclaim and general-to-personal inference adversarial cases. Independent review disagreements stay explicit.
- Real-data UI: six cards, selected address/date remains synchronized, matching evidence per claim, unknown review failure differs from missing fact, no fabricated no-law conclusion, future and failed cases, resolved versus unresolved geography.
- Regression: all existing raw outputs and all 500 address IDs preserved; original predicates and source hashes unchanged by the presentation layer.
- Accessibility: keyboard flow, drawer focus/return/Escape, screen reader labeling, mobile legibility, contrast, plain text safety and HTTP(S)-only citations.
- Human check: ask a nonexpert to find what is supported, what fact is missing, where evidence is and whether a pending law protects them today. Record exact tasks and outcomes, not a blanket readability score. One person's success is limited evidence, not universal validation.

## Recommended order after strategy and external critique

1. Agree answer contract/reason taxonomy and release criteria, retain the raw audit view.
2. Resolve selected controlling-law and consolidation decisions necessary to answer the six questions, leaving explicit gaps where evidence cannot decide.
3. Generate and independently review sourced plain-language claims; no free-form UI model answers.
4. Implement compact resident presentation with scoped homework; preserve condition visibility and query dates.
5. Test actual saved data and human comprehension, then refresh demo/submission claims.

No new legal assertions, no paid calls, no browser execution and no implementation edits were performed in this review.



---
# Packet file: internal_reviews/challenge.md
# Challenge coverage red-team review

Review timestamp: 2026-10-04 UTC. Role: independent challenge/delivery reviewer. Scope: offline inspection only; no engine/app changes, new API calls, deployment, or submission. This is a strategy critique, not legal review or evaluator scoring.

## Evidence inspected

- `challenge/participant-final-no-hour16/mit-rental-housing-law-navigator-challenge-v5-participant-no-scoring-no-hour16.pdf`, all six pages (text extracted with `pdftotext -layout`).
- Same directory: `README.md`, `schema/rule_record.schema.json`, `dev/change_tests.json`.
- `latest-four/engine-v2_3/20261004T023146-7b62feda/report.json`, `rules.json`, `lookups.json`, `changes.json`.
- `latest-four/demo-v3/RETURN_SUMMARY.md` and `presentation/submission_v3/official_verification.md`.
- `latest-four/sources-v4/supplemental_sources/county_layer/COUNTY_LAYER_AUDIT.md`.
- Current HackOS requirements below were supplied as coordinator-confirmed screenshot findings; this reviewer did not independently view those screenshots.

## Decision

Proceed toward a resident-first release, but do not describe the product as legally complete, all challenge tests passed, or 286 legally verified answers. The present release demonstrates automated extraction, conservative unknown handling, linked evidence, legal-place resolution, and reproducible date/change snapshots. Its greatest substantive task gap is cross-rule precedence; its greatest product gap is too many raw legal records before the reader gets an answer; its greatest submission risk is using stale presentation requirements and counts.

The challenge's primary question is “which rules apply here today,” not “which extracted records could be related to this address.” Humanization is therefore essential, but cannot substitute for determining which overlapping protections govern.

## Inspected facts versus stronger claims

Latest report: 310 rules, 286 approved coverage predicates, 24 unresolved, all 500 addresses, 10 new calls in this pass, estimated $1.76364, no run errors. Those are reported outcomes, not counsel certification. Reading saved default lookup output produced 22,650 `unknown`, 9,215 `applies`, 979 `not_yet_effective`, and 440 `pending` entries, with **zero `superseded` entries**. Thus roughly 68% of returned default rule/address entries are unknown. This percentage is NOT a property-level accuracy score; an address can have both known and unknown rules.

All six categories and state/city rule levels appear. 211 of 310 records have no effective date. Null dates are honest where evidence is absent, but strengthen the need to qualify historical/future snapshots. No record has a dedicated `penalty` property. The PDF requests penalty capture, but supplied JSON schema does not define that property; penalties may exist in extracted requirement text or separate rule records. A field absence is not proof that penalties were omitted, so add a completeness audit before claiming penalty coverage.

Report T1-T5 statuses all say pass. T2 has 88 affected addresses, **zero confirmed affected**, 88 potential affected, 93 unknown. PDF p4 says local bans apply only inside city limits; dev test refers to local rule applicability. The current internal test's potential-notification interpretation is useful and disclosed, but is a weaker test than proving local ban eligibility. Label it “boundary/change notification check passed; individual coverage unresolved,” never just “T2 passes.” T1 and T3 each also retain unknown entries despite confirmed change notification sets. T4's all-MA affected set is hypothetical pending legislation, not operative protection. T5's empty set correctly demonstrates a negative finding, assuming failed source status remains supported.

## Prioritized gaps and acceptance gates

### P0: Preserve the distinction between legal answer, missing data, unreviewed interpretation, and possible change

The resident view must not present all unknowns as missing building information. The 24 unresolved predicates represent interpretation/review gaps, whereas approved predicates can still yield unknown due to unavailable facts. Missing city, missing owner/occupancy facts, source integrity concerns, disputed dates, and incomplete precedence are different causes requiring different messages.

**Acceptance gate:** Every category card derives from linked rule IDs and lookup results. Applies, fact-dependent, not-yet-effective, pending, failed, conflict, source unavailable and unresolved-review states are kept distinct. A card cannot assert a protection if only unknown evidence supports it. “No applicable rule found in the reviewed sources” is not “there is no law.” Conditional claims preserve conditions and dates. Empty categories disclose corpus coverage limits.

### P0: Correct the submission package now, before recording

Demo-v3 is visibly stale: it inspected engine 2.1, says T1 fail/T2-T3 not_run, and expects two videos based on older FAQ. Current coordinator-confirmed HackOS screenshots require three uploaded videos—team introduction, product demo, technical walkthrough—each MP4/MOV <=60 seconds and <=1GB, plus valid GitHub repository link, photo JPG/PNG/WebP <=10MB, and two submissions (HackOS and linked Google Form). Deadline 9AM October4 Eastern, grace to9:15; plan before9. A public app URL is valuable even where exact required marker is uncertain.

**Acceptance gate:** Final scripts, method note, deck, README, requirement map, and app banner all describe the same release. Three real files watched end-to-end and durations checked. Final GitHub link accessible to judges, app link tested independently, JSON files and one-page method note included, both form submissions have retained receipts. Do not present older presentation smoke tests as current UI/legal tests.

### P1: Cross-rule precedence and duplicate handling before a single headline cap

README section5 defines `superseded`; PDF p1/3 asks state/local overlap and precedence, particularly rent caps. Report admits no reviewed cross-source stricter-rule supersession or duplicate consolidation. The saved default output has zero superseded results. A six-card summary selecting a visually neat cap without reviewing precedence could introduce a serious regression.

**Acceptance gate:** Targeted evidence-supported precedence relationships, not generic “city wins,” with property/date coverage independently established before superseding. Where unresolved, display both rules and the conflict clearly, avoid a single governing cap. Test an applicable local/state overlap, a local exemption where state still applies, unknown local coverage, and before/after date cases. Deduplicate display by supported provision identity while preserving every source/record and amendment lineage in the audit.

### P1: Strengthen local-ban semantics without forcing approval

Three targeted predicates remain rejected because primary residence/exclusion evidence cannot be inferred from generic residential dataset status. Do not repeatedly ask a model to approve the same inference. Missing facts can be represented as missing facts within an otherwise reviewed predicate, but legal definitions/exclusions must be supported first.

**Acceptance gate:** Reviewer checks supported primary-residence and care/detention/owner/agent conditions; evaluator receives only public or explicitly user-supplied facts with provenance. Unknown remains unknown when a required fact is absent. Boundary checks exclude Newark and unresolved legal cities. If needed preserve the weaker notification check while openly stating T2 eligibility not resolved.

### P1: Explain like neighbors, preserve claim-level support

The PDF makes plain-language explanations part of required Module B/Explain, while English/Spanish renter-facing view is a stretch goal. Schema `requirement` is one or two plain-language sentences. The existing record volume overwhelms the task. “Check my homework” should reveal the support for the exact human statement, not merely a source homepage.

**Acceptance gate:** One category heading + one concise answer + necessary qualification; expandable exact passage, official citation/link, retrieved/as-of date and decision boundary for each material claim. Explain “unknown” as an action or reason when known. Text condensation independently checked against supporting evidence for omitted exceptions, dates, numbers and actors. Numeric caps/formulas must not be invented from unavailable facts. English/Spanish only if both are reviewed and tested; no pretending machine translation is validated legal equivalence.

### P1: Corpus completeness and provenance ledger

54 supplied captures do not establish completion of all87 sources. 33 link-only/access gaps and D056 capture-status inconsistency need an explicit disposition ledger. All organizer-byte hash mismatches remain unresolved: a separately pinned snapshot proves reproducibility of inspected text, not original integrity. Santa Ana has laws but no sample addresses, so it must remain represented in extraction coverage rather than being dropped due to address absence.

**Acceptance gate:** For each87 source ID, captured/linked/unavailable status, terms/access decision, extraction outcome, rejection reason, raw/transcribed/third-party host distinction, retrieval date, original hash versus actual hash. Rule-level exact evidence gate remains unchanged. Show completeness as known/unknown, not a blanket full-corpus success.

### P2: Legal stack, arbitrary queries and temporal boundaries

County stack is required by PDF, but supplied rule schema/corpus allow state/city only. Existing county geography is a sound response; do not invent county legal rules or schema enums. All500 addresses must remain present even when city unknown. “Any apartment address” appears in introductory aspiration; minimum evaluation scope explicitly uses sample addresses. Four saved dates meet supplied test dates, but do not imply a live arbitrary-address/any-date service.

**Acceptance gate:** App clearly states sample scope and available as-of dates. Legal city versus mailing city visible on inspection. Unknown city cannot inherit postal-city ordinances. County layer shows geography/provenance and county-law coverage limitation. If arbitrary dates/addresses are added, use the same pipeline and actual data retrieval, not nearest saved snapshot presented as current law.

## Efficient refinement order

1. Freeze current release with hashes and truthful baseline evidence.
2. Agree claim semantics, missing-fact taxonomy, precedence risks and release acceptance gates through this red team and external Claude review.
3. Implement a resident front page over preserved audit detail; targeted claim explanation review, not fresh whole-corpus reruns.
4. Target precedence and a small number of consequential unreviewed coverage issues, using full linked evidence and explicit expected outcomes.
5. Reproduce critical cases and exact output consistency; test responsive/keyboard flows using final data, not fixtures alone.
6. Publish early enough to test evaluator-accessible URLs; update docs and record three final videos from actual release; submit both forms before9AM.

Budget permission is not a reason to repeat the 300-rule interpretation process. Pay for bounded comparative critique or a necessary targeted repair, with logged inputs, outputs and disposition. Broad live updates, new jurisdiction and Spanish are stretch work; prioritize correctness, readability and submission first. A documented refusal to guess is stronger evidence than manufacturing a fully green dashboard.

## Judge-facing framing

Safe: “We extracted structured rules automatically, preserved exact source evidence, reviewed coverage logic separately, and show where missing facts prevent an answer.”

Unsafe: “All rules legally verified,” “100% accuracy,” “all five organizer tests fully passed,” “286 protections apply,” or “we cover every county law.”

Do not infer numerical weights from the v5 filename or a removed scoring appendix. Any photographed scoring slide is a distinct authority that the coordinator should transcribe and reference separately. This reviewer did not inspect those images and therefore assigns no percentages. No hosting/model sponsor mandate is established by the documents inspected.

## Coordinator baseline assessment

Inspected `review/strategy-v1/BASELINE.md` after drafting this critique. The baseline is substantially honest and aligned with this review, particularly T2 qualification, snapshot rather than live scope, missing facts and precedence risk. Recommended refinements:

- Explicitly include penalty completeness and Santa Ana extraction-only coverage in the acceptance map; neither should disappear when designing around six resident questions and nine sample cities.
- Preserve a compact visible confidence/limitation statement, but do not display model confidence as a probability of legal correctness.
- Treat “strictly one sentence” as a design preference, not an acceptance rule; an important exception can justify a second concise sentence.
- Export the requirement map with columns requirement authority/page, implementation evidence, actual test type/date, gap, release acceptance gate. This prevents upstream fixture checks, current Windows tests and inferred legal claims blending into one PASS count.
- Have external Claude challenge the strongest product headline and unresolved-precedence handling rather than just polish the strategy. Ask it which remaining gap can cause a materially wrong answer, which can remain disclosed, and which claims should be removed from the demo.



---
# Packet file: DECISION_LOG.md
# Coordinator response to internal review
All dispositions below are strategy decisions, not completed implementation fixes.

| Finding | Disposition | Reason and next acceptance gate |
|---|---|---|
| T2 internal pass weaker than PDF applicability | Accept | Preserve original report but label notification boundary; separately evaluate eligibility. Zero confirmed remains visible. |
| T1/T3 partial transitions; T4 confirmed is hypothetical | Accept | Per-rule transition assessment and explicit pending hypothetical wording before demo. |
| No precedence or supersession stage | Accept | Evidence-reviewed interactions before one governing cap; unresolved overlap stays visible. |
| Unknown legend conflates failures and facts | Accept | Structured reason taxonomy and regression for each class. |
| 286 predicates mistaken for legal accuracy | Accept | Label model review separately from truth, applicability and measured accuracy. |
| Six answers could hide material conditions | Accept | Shortness is a preference; retain decisive qualification and claim receipts. |
| Handoff unsafe URL/official labels/sample schema | Accept | Adopt philosophy, preserve current safe URL/text rendering; validate a real contract. Do not copy illustrative shortened quotes. |
| Source completeness/date/penalty representation | Accept |87-source ledger, separate raw/transcribed/hosted evidence; audit penalties against schema-compatible outputs. |
| County geography and Santa Ana scope | Accept | County-law coverage disclosed; Santa Ana included in extraction accounting. |
| Stale presentation/two videos | Accept | Reconcile final release and three observed HackOS video requirements. |
| Broad reruns/extra jurisdiction/live monitoring | Defer | Core answer-changing gaps and submission take priority. |
| Spanish view | Conditional stretch | Only after English semantics, actual-data UI and delivery are covered. |
| Perfection/legal certification from reviewers | Reject | Model agreement cannot establish legal truth or organizer acceptance. |

Open disagreement: challenge reviewer suggests UI before precedence repair; evidence and resident reviewers put governing-law work first. Coordinator resolution: define the answer contract first, work on precedence and concise supported prose together, and publish a definitive category conclusion only after its governing-rule gate passes. Unresolved cards can be implemented without selecting a winning rule.

Claude critique pending. Do not automatically adopt it; append specific accept/reject/defer reasons, required evidence and regression cases. No app implementation resumes until that reconciliation is recorded.



---
# Packet file: REVISED_STRATEGY.md
# Coordinator strategy — candidate for external review

Status: internal review candidate. Implementation paused; Claude critique pending. No promise of perfection. A model disagreement is a signal to inspect evidence, not a vote on legal truth.

## 1. Protect the working baseline
Keep existing source snapshots, API responses, output versions and logs. Record exact reviewed release, hashes, model, date and limitations. Retain canonical rules/lookups/changes contracts. Add the resident explanation as a separately validated presentation layer, not a replacement for legal records. No broad rerun simply to increase the percentage approved.

## 2. Correct claims before improving appearances
Separate reported internal checks from PDF acceptance. T2 currently establishes city-bound potential notification, not confirmed eligibility. Do not claim completed local-ban applicability. Treat 286 approved predicates as model-review outcomes, not 286 correct laws or a measured accuracy percentage. Preserve unknown legal dates, unavailable texts and source-integrity mismatch. Judge-facing metrics must identify fixture checks, offline checks, saved live-model results and observed browser checks separately.

## 3. Close answer-changing legal gaps
Audit the 24 unresolved predicates by rejection reason. Where a missing fact is genuine, compile a conservative expression with an explicit missing-fact reason; do not make dataset residential scope prove primary residence, owner type, detention/care exclusion or certificate date. Where the evidence chain is inadequate, remain source/status/review unresolved. Retrying is justified only by new evidence or a changed compiler approach that addresses a specific rejection.

Prioritize duplicate legal records and state/city precedence for rent caps and just cause. A smaller number is not sufficient to choose the governing cap: jurisdiction, coverage, statutory exclusions and effective dates must all be supported. Any precedence edge needs source IDs, exact support, reviewer result and a test where missing facts block certainty. Preserve secondary sources separately. If no safe resolution is possible within the submission window, the resident answer must explain the unresolved choice, and the submission must list it as a gap.

County geography remains distinct from county-law ingestion. Audit all 87 manifest records by captured, inaccessible, linked-only or superseded/versioned condition; document completeness by source, not rule count. Santa Ana is in corpus scope even though no supplied sample city is Santa Ana. No new jurisdiction or live-monitoring stretch work until core acceptance is addressed.

## 4. Make a resident answer with a claim ledger
Main question: What housing rules apply to my home? Show supplied address selection and the actual saved query date. Six category questions: How much can my rent rise? What rules govern eviction? How much can the deposit be? What application fees are allowed? What can a landlord check? What rules govern rent-setting software?

Each category contains a short answer and any condition that changes its meaning. One sentence is a preference, not a correctness requirement. Do not merge varied rules into a single yes/no status. A category may contain established protections alongside unresolved parts; say that explicitly. Omitted or unloaded law does not mean no protection.

Public reason classes: need property/tenancy fact; legal jurisdiction unresolved; source/status not verified; eligibility logic not reviewed; unresolved overlap/conflict; pending; not yet effective; failed change. Include the most useful supported next fact/question when known, but never promise that one additional fact will settle multiple unresolved issues.

Each material sentence has support IDs. Check my homework opens only its supporting receipts: exact quote, citation, source URL, retrieval date, query date, verified effective date/status, limits and conflict. Geography and property-data claims cite their own inputs, not a law that does not establish those facts. Source hash disagreement is available in the audit; answer-changing limitations are visible with the answer.

## 5. Validate translation separately
Generate explanations from frozen evidence and results, with an independent semantic review. Check subject, trigger, jurisdiction, threshold, dates, exemptions, operative status and lack of fabricated applicability. Mechanical support-ID existence alone does not establish semantic support. Reject unsupported summaries instead of polishing them. Useful translations remain conditional where evidence is conditional.

Regression cases: reviewed predicate but missing owner/CO; unreviewed predicate with complete sample data; uncertain city; multiple local/state caps; pending proposal; future enactment; failed ballot; mixed known/unknown category; source unavailable. Plain-language fallback is specific and short. Optional Spanish only after English passes, with the same evidence ledger and semantic checks.

## 6. Verify the real screen and release
Test actual 500-address saved data, date switching, scoped homework, keyboard/mobile, unknown reason classes and T1–T5 details. Existing fixture browser proof is useful but does not prove production data/browser deployment. Keep full details and audit accessible; remove raw engine prose from the initial resident view.

## 7. Deliver and demonstrate
Reconcile method note/deck/scripts with final evidence, not older counts. Create GitHub-ready review records; verify actual public repository permissions and deployed Render URL. Three <=60-second videos: human introduction; product story (answer, homework, change); technical walkthrough (automated extraction, geography, conservative eligibility, evidence and reproducibility). Complete HackOS and linked Google Form before9AM EDT Oct4; confirm receipts. Reserve at least90 minutes for recordings, uploads, permissions and recovery. External review is timeboxed to one critique and a documented response; no endless review loops.

## Completion standard
For every PDF/slide requirement: attach observed evidence or a named remaining gap. A release can be usable with honest unknowns; it cannot be called complete by renaming failed eligibility as notification success. No counselor certification, safety guarantee, evaluator score or measured legal accuracy is claimed without corresponding evidence.



---
# Packet file: bill_xray_handoff/HOUSING_NAVIGATOR_WRITING_PROMPT.md
# Housing Navigator plain-language + evidence prompt

You are the public-language layer for Housing Navigator.

Your job is not to sound legal. Your job is to let an ordinary person understand what the evidence supports about their home without changing the law's meaning.

## Writing target
Write the way one careful, informed neighbor would explain the rule to another neighbor.

Use short sentences. Lead with the practical answer. Preserve every material condition that can change applicability.

## Never lose
- jurisdiction
- property type
- tenancy / ownership status
- owner occupancy when relevant
- thresholds
- dates
- deadlines
- exceptions
- exemptions
- procedural prerequisites
- unresolved cross-references
- source conflicts
- uncertainty

## Evidence contract
Every material legal statement must have one or more `support_fact_ids`.
Every support fact must resolve to a receipt containing an authoritative citation and source.

If a sentence cannot be supported, do not soften it or hedge it into publication. Remove it, turn it into a question, or mark the answer unresolved.

## Public-answer structure
1. State what appears to apply, or say that there is not enough information.
2. State the condition(s) that make that answer true.
3. State the exception / uncertainty most likely to change the answer.
4. Stop before the prose turns into a legal memo.

## Internal evidence states
- `SUPPORTED_NARROWLY`
- `QUESTION_ONLY`
- `HOLD`

Public wording:
- SUPPORTED_NARROWLY -> concise answer + conditions
- QUESTION_ONLY -> "We found something worth checking, but not enough to say this applies."
- HOLD -> "I can't support an answer yet."

## Missing data
A missing source means `NOT LOADED`, not `DOES NOT EXIST`.
A missing household/property fact means `NEED_MORE_INFO`, not an inferred yes/no.

## Conflicts
Keep conflicting authoritative sources separate. Identify the source type and the point of conflict. Do not average disagreement into one confident sentence.

## Check My Homework block
For every answer provide receipts containing:
- plain-language claim
- citation / section
- source title + URL
- exact supporting passage
- effective date if verified
- publication date if verified
- retrieval date
- current-law status as of a specific date
- Limit: what the source does not prove
- unresolved facts
- conflicts, if any

## Final quality test
Before returning an answer ask:
- Can a normal person understand this in one read?
- Did I keep the condition that makes the rule true?
- Did I keep the exception that can change it?
- Did I preserve the date?
- Does every legal assertion have evidence?
- Did I claim applicability without all required facts?

If the last answer is yes, rewrite.



---
# Actual evaluator code (read-only snapshot)
```python
"""Deterministic three-valued property coverage; no manually authored legal rules."""
import datetime as dt
CITY_STATE={'Los Angeles':'CA','San Francisco':'CA','San Diego':'CA','Berkeley':'CA','Santa Ana':'CA','Boston':'MA','Cambridge':'MA','Jersey City':'NJ','Hoboken':'NJ','Newark':'NJ'}
FIELDS={'dataset_residential_scope','units','year_built','use_code','use_description','owner_type','owner_occupied','owner_properties','certificate_of_occupancy_date','exemption_notice','eviction_ground','tenancy_duration_months','subsidized','rso_registered','new_construction_exemption','tenant_service_member','tenant_age','tenant_disability','rent_amount','deposit_amount','lease_type','tenancy_start_date'}

def validate_predicate(p,depth=0):
    if depth>12 or not isinstance(p,dict):raise ValueError('Invalid/deep coverage predicate')
    op=p.get('op')
    if op in ('true','false'):return
    if op=='unknown':
        if not isinstance(p.get('reason'),str) or not p['reason'].strip():raise ValueError('Unknown needs an explanation')
        return
    if op in ('all','any'):
        if not isinstance(p.get('args'),list) or not p['args'] or len(p['args'])>20:raise ValueError('Invalid predicate arguments')
        for x in p['args']:validate_predicate(x,depth+1)
        return
    if op=='not':validate_predicate(p.get('arg'),depth+1);return
    if op=='cmp':
        if p.get('field') not in FIELDS or p.get('comparison') not in ('eq','ne','lt','le','gt','ge','starts_with'):raise ValueError('Invalid field/comparison')
        v=p.get('value')
        if not isinstance(v,(str,int,float,bool)) or isinstance(v,float) and (v!=v or abs(v)==float('inf')):raise ValueError('Invalid comparison value')
        if p['field'] in ('units','year_built') and (not isinstance(v,(int,float)) or isinstance(v,bool)):raise ValueError('Numeric field needs numeric value')
        if p['comparison'] in ('lt','le','gt','ge') and p['field'] not in ('units','year_built','certificate_of_occupancy_date','tenancy_duration_months','owner_properties','tenant_age','rent_amount','deposit_amount','tenancy_start_date'):raise ValueError('Invalid ordered comparison')
        return
    raise ValueError('Unknown predicate operator')

def facts(address):
    # Only supplied assessor facts are available. No synthesized owner, tenant or certificate fields.
    out={k:address.get(k) or None for k in ('units','year_built','use_code','use_description','dataset_residential_scope')}
    for field in ('units','year_built'):
        try:out[field]=int(out[field])
        except (ValueError,TypeError):out[field]=None
    return out

def coverage(p,f):
    op=p['op']
    if op=='true':return True,[]
    if op=='false':return False,[]
    if op=='unknown':return None,[p['reason']]
    if op=='not':
        value,why=coverage(p['arg'],f);return (None if value is None else not value),why
    if op in ('all','any'):
        evaluated=[coverage(x,f) for x in p['args']];values=[x[0] for x in evaluated]
        if op=='all' and False in values:return False,[]
        if op=='any' and True in values:return True,[]
        if None in values:return None,list(dict.fromkeys(y for _,why in evaluated for y in why))
        return (all(values) if op=='all' else any(values)),[]
    value=f.get(p['field'])
    if value is None:return None,['Missing '+p['field']]
    expected=p['value'];operator=p['comparison']
    if type(value)!=type(expected) and not (type(value) in (int,float) and type(expected) in (int,float)):return None,['Incompatible '+p['field']+' fact']
    ops={'eq':lambda:value==expected,'ne':lambda:value!=expected,'lt':lambda:value<expected,'le':lambda:value<=expected,'gt':lambda:value>expected,'ge':lambda:value>=expected,'starts_with':lambda:isinstance(value,str) and isinstance(expected,str) and value.startswith(expected)}
    return ops[operator](),[]

def date_status(rule,normalized,as_of):
    query=dt.date.fromisoformat(as_of)
    if rule['status']=='failed':return None,'Failed measure; no current protection'
    if rule['status']=='pending':return 'pending','Proposal is pending; not current law'
    effective=normalized.get('effective_date') if normalized else rule.get('effective_date')
    if effective:
        try:start=dt.date.fromisoformat(effective)
        except (ValueError,TypeError):return 'unknown','Effective date lacks day-level precision'
        if query<start:return 'not_yet_effective','Enacted rule is not yet effective on this query date'
        return 'applies','Effective-date gate passed'
    if rule['status']=='not_yet_effective':return 'not_yet_effective' if query<=dt.date(2026,10,1) else 'unknown','Exact effective date unresolved'
    if as_of!='2026-10-01':return 'unknown','Historical/future status not established by the default-date snapshot'
    return 'applies','Source snapshot reports rule in force on the default query date'

def lookup(address,geo,rules,normalized,as_of):
    result=[];city=(geo.get('jurisdiction') or {}).get('legal_city') if geo else None
    for rule in rules:
        jurisdiction=rule['jurisdiction'];boundary_unknown=False
        if rule['level']=='state':
            if jurisdiction!=address['state']:continue
        else:
            if CITY_STATE.get(jurisdiction)!=address['state']:continue
            if city is not None and jurisdiction!=city:continue
            boundary_unknown=city is None
        norm=normalized.get(rule['team_rule_id']);status,date_note=date_status(rule,norm,as_of)
        if status is None:continue
        if norm:
            fits,why=coverage(norm['coverage'],facts(address))
            if fits is False:continue
        else:fits=None;why=['Coverage compilation did not pass independent review']
        if boundary_unknown:fits=None;why+=['Legal city unresolved; local coverage is unverified']
        if status=='applies' and fits is None:status='unknown'
        explanation=date_note+'. '+(norm['coverage_note'] if norm else '')
        if why:explanation+=' Coverage uncertainty: '+'; '.join(why)+'.'
        if status=='applies':explanation+=' Property coverage passed; the cited requirement still governs its stated transaction/event conditions.'
        result.append({'team_rule_id':rule['team_rule_id'],'result':status,'explanation':explanation.strip(),'conflict_flag':bool(rule.get('conflict_flag',False))})
    return result

```