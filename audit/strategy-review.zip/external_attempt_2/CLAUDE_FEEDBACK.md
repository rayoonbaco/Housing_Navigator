# Independent Critique: Rental Housing Law Navigator Strategy

**Limits:** I have not seen the live app, repository, raw legal sources, code, or the 87-document corpus. I am critiquing the supplied text only. Every pass/fail figure below is a claim I cannot verify. I am not certifying law, and my agreement or disagreement is not accuracy evidence.

---

## 1. Verdict and top 5 risks

**Verdict:** The strategy is honest about its weaknesses, but it is a plan to fix problems, not evidence that they are fixed. It also spends a scarce window (an estimate of ~hours remaining before 9AM EDT with 90 min reserved) on a large rewrite (precedence, translation validation, claim ledger, reason taxonomy, plus Spanish). The strongest move is to ship a conservative, honestly-labeled saved-run viewer, and treat every legal claim as unverified.

**Top 5 risks**

1. **T2 is not a pass against the PDF.** The PDF says apply each local ban *only inside its own city limits, not in Newark*. Zero confirmed / 88 potential / 93 unknown demonstrates a boundary filter, not applicability. Labeling it "pass" in any judge-facing artifact is the largest credibility risk.
2. **Precedence is unimplemented, yet "stricter rule" is a slide-7 requirement.** Zero "superseded" across all results means the system cannot currently tell a resident which cap governs. Any category summary risks implicitly selecting one.
3. **Source completeness and dates are weaker than the headline.** 211/310 effective dates null, 33 link-only sources, D056 missing despite capture=yes, 54 hash mismatches, Jersey City operative dates unresolved. The as-of-date and "enacted vs in effect" features depend on exactly these.
4. **Same-model review is circular.** 286 "approved" predicates were reviewed by a model; that is consistency, not correctness. Nothing in the supplied evidence measures legal accuracy.
5. **Delivery risk.** Public deployment, GitHub, team photo, three videos, HackOS plus Google Form are all undone, while the plan front-loads new engineering. The stale deck (engine-2.1) adds reconciliation work.

---

## 2. Unmet core requirements vs. justified unknowns vs. stretch

**Unmet core (PDF/slides)**
- **T2 applicability:** not shown beyond a city-boundary notification (0 confirmed).
- **Local-vs-state precedence and local-vs-FAIR-Act conflict flagging (T3):** the PDF requires "flags possible conflicts with local bans." The strategy's own gap list says precedence and duplicate consolidation are unfinished. I cannot tell from the supplied text whether conflict flags exist in `changes.json`.
- **As-of-date query:** the PDF requires support for it. The baseline says the UI is a saved-run viewer, "not arbitrary-date evaluation." Whether the engine supports arbitrary dates is not stated. The UI and engine may differ; this must be confirmed rather than assumed.
- **Penalty capture:** the PDF lists penalty among required extraction fields; findings say the supplied schema lacks one. Note the discrepancy: the PDF text and the schema disagree, so the gap needs to be disclosed, not just "audited."
- **Required deliverables not produced:** public demo, method note reconciled with current counts, three videos, submissions.

**Justified unknowns (acceptable if labeled)**
- Owner type, certificate of occupancy date, tenancy facts, primary-residence status: PDF explicitly allows "unknown."
- 20 unresolved legal cities, if they genuinely fail geocoding.
- Pending (T4) and failed (T5) items yielding conditional or empty sets.

**Stretch (defer)**
- Spanish view, extra jurisdiction, live monitoring, confidence numbers. The strategy defers these correctly, but "conditional stretch" for Spanish should simply become *cut* unless everything else is done. Note the slide point weight for "scale" is only 5.

**Unjustified "unknown"**
- 24 unresolved predicates, which are compiler or review failures, not missing facts. Calling these "unknown" in the same legend as a missing fact is misleading (the strategy accepts this).

---

## 3. Three concrete counterexamples

**Counterexample A: the "pass" that hides non-applicability (T2).**
Take a Hoboken address in the 88. The report says T2 "pass." A judge asks, "Does the Hoboken ban apply to this building?" The system's honest answer is "we don't know; zero confirmed." Meanwhile Newark addresses are excluded, so the *negative* half passes. A pass defined as "only inside city limits" is trivially satisfiable by a city filter plus an unresolved eligibility step. Also, 93 unknown vs 88 affected means at least five addresses are unknown for reasons the report does not explain. If the 88 set depends on the 20 unresolved cities or on mailing-vs-legal city mismatch, the boundary itself may be wrong at the margins. I cannot tell which from the evidence.

**Counterexample B: the six-category summary selecting a governing rule.**
A Los Angeles address could carry a statewide rent-cap record, a local rent-stabilization record, and a duplicate or secondary-source record of one of them. Zero "superseded" means all three surface as "applies." A one-sentence "How much can my rent rise?" must either list three numbers, pick one, or say "unresolved." Any default (first, highest-confidence, lowest cap) is an unreviewed precedence decision. The strategy accepts this risk. The practical consequence is that rent cap and just-cause categories may have to ship as "multiple rules apply; governing rule not determined" for most cities, which is a weak slide-5 demo but an honest one.

**Counterexample C: "T1 pass" with half the transition unknown.**
T1 reports affected=250 and unknown=250, and `confirmed_affected=250`. Identical counts suggest every affected address also carries an unknown rule, and the acceptance rule is "at least one applicable transition per address." A claim like "250 California addresses are affected by AB 325/SB 763 from 2026-01-02" is defensible only as "each has at least one rule that transitions." For the six rule IDs listed, an address could have two rules changing status while four remain unknown on facts such as unit count or ownership. A resident reading "affected" will assume the whole law now applies. The same pattern holds for T3 (140/140).

A secondary counterexample (stale artifact): the deck describes engine-2.1 and counts; the saved run is engine-2.3. Any judge comparing the deck to `rules.json` will find mismatched numbers.

---

## 4. Internal recommendations: accept / reject / change

| Recommendation | My call | Note |
|---|---|---|
| T2 relabel; zero confirmed visible | **Accept, strengthen** | Do not use "pass" in demo copy at all. Report as "city-bound; eligibility unresolved." Also explain the 93 unknown. |
| Per-rule T1/T3 transition assessment | **Accept, downscope** | A full per-rule matrix may be too costly now. Minimum: demo wording that says "at least one rule changes status" plus listing which rules remain unknown. |
| Precedence/supersession stage | **Change** | Accept the goal; reject building a general stage in the time left. Replace it with a narrow, hand-audited interaction list (state vs city rent cap, just cause) for LA/SF/etc., each with source IDs and exact quotes, and default everything else to "overlap unresolved." Note that "hand-audited" affects the "extraction must be automated" requirement: keep the precedence layer clearly as a *reviewed overlay*, not part of extraction. |
| Reason taxonomy for unknown | **Accept, high value, low cost** | This is mostly labeling and probably the best honesty improvement per hour. |
| Label model review vs truth | **Accept** | Do not publish "286/310" without the qualifier, and avoid any percentage-correct language. |
| Short answers must keep material conditions | **Accept** | Mandate a visible "condition that changes this answer" slot. |
| Bill X-ray adoption | **Change** | Adopt the receipt idea, not the code, since I cannot see it. Keep current safe URL and text rendering. Do not import "official" labels. |
| Source ledger by condition (captured/link-only/versioned) | **Accept** | Cheap, and it directly supports the audit-view stretch and the honesty story. |
| Separate semantic review of translations | **Change** | A second model pass is still same-model agreement. Limit it to checks that can be mechanical (quote present, dates match, status string matches). Do not describe it as validation. |
| Defer reruns, extra jurisdiction, live monitoring | **Accept** | |
| Spanish "conditional stretch" | **Reject for now** | Cut. Revisit only if the delivery gate passes with more than 90 min spare. |
| Reject reviewer-perfection / legal certification | **Accept** | |
| Unresolved: UI-first vs governing-law-first | **Change** | Neither. Do an unresolved-card UI that never names a winner (cheap, honest), then precedence for only the highest-stakes categories if time remains. |

---

## 5. Revised work order through 9AM EDT Oct 4 (90 min reserved for delivery)

I do not know the current clock, so this is sequenced by priority with proportional time. **Working cutoff = 7:30 AM EDT; 7:30–9:00 delivery only.** If less than ~3 hours remain at the start, drop steps 4–5.

1. **Freeze and record (≈10 min).** Tag engine-2.3 outputs, hashes, model, date. No reruns.
2. **Claim correction pass (≈30 min).** Rewrite T2 as boundary notification only. Rewrite T1/T3 as "at least one transition per address; X rules unknown." Mark T4 as hypothetical and T5 as limited to the ballot question. Replace any accuracy-sounding metric. Fix the stale deck/method-note counts.
3. **Unknown reason taxonomy and unresolved cards (≈60–90 min).** Map existing unknown records to the eight proposed reason classes. If a record cannot be classified from existing data, label it "unclassified" rather than guessing.
4. **Narrow precedence list (≈60 min, cut first if behind).** Only state-vs-city rent cap and just-cause for the California and New Jersey/Massachusetts cities where interaction is most visible. Each edge needs source ID plus quote; otherwise "overlap unresolved."
5. **Claim receipts in the UI (≈45 min).** Only for the sentences actually displayed; use exact stored spans.
6. **Real-data browser check (≈30 min).** Actual 500-address data, drawer, change tab, audit tab, mobile/keyboard. Record exactly what was observed and what was not.
7. **Public deploy (≈30 min)** and confirm the URL loads without the author's machine.
8. **Delivery block, 7:30–9:00 (90 min):** GitHub permissions check, team photo ≤10MB, three ≤60s videos, HackOS plus Google Form, receipt screenshots. Note that the observed grace to 9:15 should not be planned on.

Do not start any step after its cut line if it threatens the delivery block.

---

## 6. Testable release gates

Each gate should produce a recorded observation, not an assertion.

- **G1 T2 wording:** no judge-facing string says T2 "passes" without the qualifier; page shows 0 confirmed / 88 potential / 93 unknown. *Test:* grep the deck, README, UI, and videos script.
- **G2 Newark exclusion:** a sampled Newark address is absent from T2 potential set; sampled Hoboken and Jersey City addresses are present only when legal city matches.
- **G3 mailing vs legal city:** at least one address where they differ is shown with the legal city used, plus one of the 20 unresolved cities showing "legal jurisdiction unresolved," not a guessed city.
- **G4 no silent winner:** for an address with two or more cap records, UI shows all or "unresolved overlap," never one. *Test:* manual check on named LA, SF, Jersey City addresses.
- **G5 date gating:** T1 at 2025-12-31 shows not yet effective; at 2026-01-02 shows applies. T3 at 2026-10-01 not yet effective; 2027-07-02 applies. If only saved dates are supported, the UI says so.
- **G6 pending/failed separation:** T4 items never appear under "applies"; T5 empty-set message states it concerns only the failed ballot question.
- **G7 unknown classes:** each reason class renders distinctly with at least one real example (or is explicitly marked "not exercised").
- **G8 receipts:** every displayed material sentence opens a quote matching a stored exact span; a link with a non-http protocol fails to render as a link.
- **G9 null dates:** a rule with a null effective date shows "date not verified," not a date.
- **G10 labeling:** every screen carries "not legal advice"; no "official" label on third-party-hosted sources.
- **G11 delivery:** public URL opens from a clean browser/incognito session; GitHub repo opens logged out; three videos each ≤60s; both submissions confirmed.

---

## 7. Misleading demo claims → honest replacements

| Avoid | Say instead |
|---|---|
| "All five change tests pass" | "Five change cases run; T2 identifies city-bound candidates (0 confirmed eligible); T4 is hypothetical; T5 covers only the failed ballot question." |
| "286 of 310 rules verified" | "286 coverage predicates were approved by a model review; 24 remain unresolved. This is not a measured accuracy rate." |
| "Applies to 250 addresses" | "250 addresses have at least one rule changing status; other rules at those addresses remain unknown." |
| "Massachusetts has no rent control" | "The struck ballot question creates no rent cap; other Massachusetts law is outside what was loaded or reviewed." |
| "Shows which rule governs" | "Shows rules that may apply; precedence between state and local rules is reviewed only where marked." |
| "Live as-of-date queries" | "Browse the saved run as of the stored date" (unless arbitrary-date support is actually observed). |
| "Fully sourced / reproducible" | "Each shown claim links to a quote and retrieval date; 54 captured files differ from organizer hashes, 33 sources are link-only." |
| "Reviewed by two independent AIs" | "Cross-checked by a second model pass; this checks consistency, not legal truth." |
| "Covers California, New Jersey, Massachusetts" | "Covers the supplied corpus; county-law coverage is not established; Jersey City operative dates unresolved." |
| "No legal advice" while implying compliance | Keep the disclaimer, and do not tell housing providers a rule is "not applicable" without a reviewed exclusion. |

---

## 8. Questions a model cannot settle

**Organizer/source questions**
- Does the grader score T2 by confirmed applicability, or by the city-bound set? Is "affected" intended as "potentially" for T2?
- Is the organizer hash mismatch (all 54 captured) expected, for example because of re-download, or does it indicate a different source version?
- Does the missing D056 mean absent text, or was "capture=yes" in the manifest an error?
- Is "stricter governing rule" (slide 7) expected to be computed by teams, or only flagged?
- What do the starter-pack schema and graders expect for penalty?
- Is a county rule category expected for any in-scope county?

**Legal/domain questions (counsel or housing-law practitioner)**
- Exact operative dates and current consolidated text of the Jersey City ordinances.
- Whether, and how, the NJ FAIR Act preempts or conflicts with the local bans.
- Whether California statewide cap and local ordinances interact as the engine's records suggest, per city.
- Whether a model-approved predicate is actually correct; a sample audit by a human is the only measurement.

**User questions**
- Is the clock tight enough to cut precedence and receipts entirely and ship labeling-only?
- Does the user have a housing-law reviewer available, even for 30 minutes on a ten-rule sample?
- Which of GitHub/Render/HackOS permissions have already been tested?
- Who records the intro video, and is the team photo already in hand?

If there is only time for one thing beyond delivery, I would do steps 2 and 3. They cost little and remove the most misleading claims.