# Independent Claude strategy critique — revised bounded request
Write a complete critique in at most1800words. Cover all sections briefly rather than expanding early sections. This is an independent product/engineering review, not legal certification. Do not just affirm the coordinator. You have the full supplied challenge text, photographed-slide observations, current baseline and internal-review response ledger below. You do NOT have all raw legal source documents or the live app; state limits. Earlier attempt produced no written critique and is not evidence of your agreement.

Required sections: (1) verdict/top5risks; (2) unmet core requirements versus justified unknowns/stretch work; (3) three concrete counterexamples to the summary design or claimed passes; (4) accept/reject/change internal recommendations; (5) revised work order through9AM EDT Oct4, reserve90minfor delivery; (6) testable release gates; (7) misleading demo claims and honest replacements; (8) source/user questions that another model cannot settle.

Pay particular attention to T2 zero confirmed/88potential; source completeness and unverified effective dates; state/city stricter-rule precedence; resident prose preserving material exceptions; same-model review not accuracy; three videos/two submissions. Do not invent laws, facts, successful tests or grader results.



---
# CHALLENGE_TEXT.md
## PDF page 1
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
1
PROPOSED MIT AI HACKATHON CHALLENGE - 24 HOURS - PUBLIC DATA ONLY
Rental Housing Law Navigator
An AI system that reads public housing law and answers one question for any apartment address: which
rules apply here today, and how do the supplied change cases affect the answer?
How might AI turn thousands of pages of state and local housing law into accurate,
cited, address-level answers that renters, advocates, housing agencies and housing
providers can trust?
The problem is specific, real and getting harder
Rental housing in the United States is regulated in layers: state statutes, county rules and city ordinances, each with its own coverage
tests, effective dates and exemptions. The answer to what rules apply to an apartment depends on the exact address and the query
date.
Why it matters
What teams must handle
Layered rules
State and local rules can overlap, defer to one another or be superseded.
Address precision
A mailing city is not always the legal city. Jurisdiction resolution is part of the task.
Changing law
The supplied tests include effective-date changes, pending bills and a failed ballot question.
Who this helps
Renters
Advocates and agencies
Housing providers
Know which protections apply at their address.
See how rules cover buildings and what supplied
changes would affect.
Understand obligations before acting, especially
without legal staff.
The challenge in one line: In 24 hours, build a working system that extracts rules from a
provided corpus of real housing law, resolves sample addresses to the rules that apply
with citations, and reports the address sets affected by five supplied change cases.


## PDF page 2
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
2
WHAT TEAMS BUILD
From legal text to an address-level answer
Three required modules plus stretch goals. The starter pack lets teams spend the 24 hours on AI, workflow
design and responsible reasoning rather than data collection.
1. Extract
2. Resolve
3. Apply
4. Explain
5. Track
Turn statutes and
ordinances into structured
rule records.
Geocode an address and
build its state, county and city
stack.
Test coverage conditions
against building facts and
exemptions.
Return applicable rules with
plain-language explanations
and citations.
Run the five supplied change
cases and report affected
addresses.
Required modules
Module
Requirement
A - Rule extraction
Read each corpus document and output one structured record per rule. Extraction must be automated, not hand-coded.
Capture category, jurisdiction, requirement, coverage conditions, exemptions, effective date, status, penalty, citation and a
quoted span.
B - Address lookup
Resolve each address to its legal jurisdiction stack and report every applicable rule. If coverage depends on a missing fact,
report unknown rather than guessing.
C - Change tracking
Run the supplied change cases, list affected sample addresses and support an as-of-date query. No surprise document or
mid-event release is required.
Stretch goals
- Renter-facing plain-language view in English and Spanish.
- Confidence indicator and conflict flag for each answer.
- Extend to one new jurisdiction using the same extraction and coverage pipeline.
- Audit view showing the source, retrieval date, as-of date and reasoning boundary for each answer.


## PDF page 3
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
3
SCOPE FOR 24 HOURS
3 states - 10 cities - 6 rule categories
Small enough to finish, varied enough to be hard. The jurisdictions cover state-only rules, layered local rules
and recent or failed changes.
State
Cities in scope
Why it is included
California
Los Angeles, San Francisco, San Diego,
Berkeley, Santa Ana
Dense layering: statewide rent and just-cause rules, local rent control and
algorithmic-pricing rules.
New Jersey
Jersey City, Hoboken, Newark
City-by-city rent control, statewide eviction and screening rules, and a statewide
algorithmic-pricing law with a future effective date.
Massachusetts
Boston, Cambridge
State law bars local rent control; pending algorithmic-pricing bills and a failed ballot
question test negative findings.
Rule categories
Category
What to capture
Rent increase limits
Cap formula, covered buildings, exemptions and local-versus-state precedence.
Just-cause eviction
Allowed causes, notice, relocation assistance and coverage.
Security deposits
Maximum, exceptions and effective date.
Application and screening fees
Fee caps, allowed upfront charges, receipts and refunds.
Screening restrictions
Criminal-history and income-source limits and timing rules.
Algorithmic rent-setting
Covered software, prohibited conduct, penalties and effective date.
The corpus covers three states and ten cities. It has not been reviewed by counsel and is for prototype challenge scoping only.


## PDF page 4
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
4
TEST CASES AND STARTER PACK
Deterministic change cases, packaged data
Teams work from the same fixed corpus and address sample. Change tracking is evaluated against five
explicit cases, all defined at kickoff.
Test
What a correct system does
T1 - CA AB 325 / SB 763
Reports not yet effective on 2025-12-31 and applies on 2026-01-02 for California addresses.
T2 - Hoboken and Jersey City local bans
Applies each local ban only inside its own city limits, not in Newark.
T3 - NJ FAIR Act
Reports not yet effective on 2026-10-01, applies on 2027-07-02 and flags possible conflicts with local bans.
T4 - MA S.2983 and H.5222
Reports both bills as pending and lists the Massachusetts addresses they would affect if enacted.
T5 - MA rent-control ballot question
Reports no rent cap for Boston or Cambridge because the question was struck; affected set is empty.
Starter pack provided to teams
Item
Contents
Format
Law corpus
87 source documents with URL and retrieval date; links for sources without supplied text.
Text + CSV
Sample addresses
About 500 multifamily properties in nine cities from public assessor data. No owner names.
CSV
Rule schema
Required fields for every rule record and a worked example.
JSON Schema
Change tests
The five explicit cases above and their test definitions.
JSON


## PDF page 5
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
5
DATA AND RESPONSIBLE DESIGN
Build for transparency, not legal verdicts
The system should make housing law easier to see and understand without pretending to be a lawyer or
helping anyone work around the rules.
Public sources teams may use
Source
Use it for
State codes and municipal codes
Official statute and ordinance text.
LegiScan and Open States
Bill status, sponsors, events and text where available.
Census Geocoder and TIGER/Line
Address-to-jurisdiction resolution and boundary checks.
Public parcel data
Building facts such as year built, units and use code.
Local program lookups
Spot-checks for rent-control coverage; not a replacement for the corpus.
The solution should
The solution must not
Cite source text and retrieval date; show an as-of date; separate enacted
from pending law; say unknown when facts are missing; flag conflicts for
human review; keep an audit log.
Present output as legal advice or a compliance certification; invent rules or
citations; use non-public data; or scrape sites in violation of their terms.
A practical 24-hour plan
Time
Focus
Hours 0-1
Kickoff, starter-pack walkthrough and mentor introductions.
Hours 1-6
Rule extraction against the supplied corpus and starter-pack self-check.
Hours 6-11
Geocoding, jurisdiction stacks and coverage logic.
Hours 11-18
Address lookup, citations, plain-language view and deterministic change cases.
Hours 18-23
Validation run, fixes and demo preparation.
Hours 23-24
Demos and judging.


## PDF page 6
REALPAGE | DISCUSSION DRAFT | OCTOBER 2026
6
BUILD AND SUBMIT
Make every answer traceable
The participant guide contains the full detail. These are the build expectations and submission materials to
prepare for the event.
Build expectations
Submission package
Build Modules A, B and C from the supplied corpus and address sample.
Extraction must be automated. Unknown is valid when facts are missing.
Use public data only, respect source terms and label every interface not
legal advice.
rules.json: structured rules with citations and quoted source text; lookups.json:
results for all sample addresses; changes.json: affected addresses and conflict
flags for each supplied test; live demo and one-page method note.
A strong submission
- Shows the source document, quoted span, retrieval date and as-of date for every answer.
- Separates enacted, pending, not-yet-effective and failed changes.
- Reports unknown when a required fact is missing and flags conflicts for human review.
- Keeps a simple audit log so another person can reproduce the result.
The intended outcome: show that responsible AI can make housing law visible at the
level that matters - a single address - so renters know their rights, providers know their
obligations and every answer is traceable to its source.



---
# SLIDE_REQUIREMENTS.md
# Photographed slide observations
Coordinator and resident reviewer viewed the supplied photos. These are requirements/design cues, not production law answers.
- IMG_3059 / slide9: The law that protects a home should be readable by the people living in it; every answer traceable.
- IMG_3055 / slide6: Extract, Resolve, Apply, Explain, Track change. Explain includes plain language, quoted source and as-of.
- IMG_3054 / slide5: Compact address/context plus six short category answers with statuses. Illustrative example, not a legal result to copy.
- IMG_3056 / slide7: Unknown valid; mailing city differs from legal city; enacted differs from in effect; pending and struck measures are not current law; stricter governing rule.
- IMG_3057 / slide8:75 script points: extraction25/address20/citations15/change15;25demo:plain language10/responsible design10/scale5. Source/date, as-of, pending separation, unknown rather than guessing; no legal advice or evasion.
- IMG_3061:general judging technical depth, communication, innovation/creativity.
These weights are photographed presentation evidence, not an evaluator score assigned to this project. Full challenge PDF remains included separately.



---
# BASELINE.md
# Review baseline — 2026-10-04 UTC

Implementation is paused at the user's request. This review is a strategy critique, not legal certification or an organizer scoring run.

Current saved run: engine-2.3 / 20261004T023146-7b62feda. 310 rules; 286 model-reviewed coverage predicates; 24 unresolved; 500 sample addresses; 480 matched legal cities/counties; 20 unresolved. Forty offline engine tests passed in the user's Windows run. Coordinator previously reproduced four 500-address snapshots and preserved predicate equality; those prior checks are not newly rerun in this strategy pass.

Reported T1–T5 checks pass, with material qualifications: T2 has 88 potential city-bound notifications, zero confirmed eligible addresses; its pass does not establish the PDF's full local-applicability requirement. T1/T3 retain unknown rules alongside established affected sets. T4 is hypothetical pending legislation. T5 concerns the failed ballot question, not proof that Massachusetts has no other housing protections.

Existing UI is a saved-run browser viewer, not live legal monitoring or arbitrary-date evaluation. User screenshots show loaded address list, county metadata and rule cards. Drawer, change tab, audit tab and deployed release have not been verified on the user's current build in this review.

Known deficiencies: cross-source stricter-rule precedence and duplicate consolidation unfinished; source-byte organizer hashes differ from all 54 captured snapshots; D056 missing despite capture=yes; 33 link-only access gaps; exact Jersey City operative dates/current consolidated amendment text unresolved; official final court-hosted opinion inaccessible (third-party court-opinion hosting disclosed); county metadata does not prove county-law coverage. Missing owner/certificate/tenant facts may legitimately prevent an answer. Model review is not measured legal accuracy.

Bill X-ray handoff supplied by user: CHECK MY HOMEWORK; sentence/paragraph support IDs, receipts, expandable source excerpts and visible limitations. Repository behavior is described by the supplying canvas and code extracts; coordinating canvas has inspected the supplied handoff, not independently audited its live repository. Housing-specific schema and six-answer pattern are proposals, not implemented here.

Proposed direction for red-team challenge: six concise resident questions; date and legal geography; claim-specific receipts; actual unknown reason categories; retain all engine records behind details; prevent a summarized category from selecting a governing rule without reviewed precedence; publish unsupported answers as unresolved. No fixed universal one-sentence limit if it hides a decisive condition.

Submission requirements observed in user HackOS screenshots: valid GitHub link, team photo <=10MB, three separate <=60-second intro/demo/technical videos, HackOS plus linked Google Form. Public deployment and final submission remain undone. Deadline 9AM Eastern Oct4 (grace to9:15 observed; plan before9). Presentation source package describes an older release and must be reconciled.



---
# CURRENT_RUN_REPORT.json
{
  "version": "engine-2.3",
  "as_of": "2026-10-01",
  "rules": 310,
  "coverage_approved": 286,
  "coverage_unresolved": 24,
  "addresses": 500,
  "genuine_api_calls": 10,
  "estimated_usd": 1.76364,
  "change_tests": [
    {
      "test_id": "T1",
      "status": "pass",
      "affected": 250,
      "unknown": 250,
      "confirmed_affected": 250,
      "potentially_affected": 0,
      "rule_ids": [
        "HN-SUP-P001-001",
        "HN-SUP-P001-002",
        "HN-SUP-P001-003",
        "HN-SUP-P002-001",
        "HN-SUP-P002-002",
        "HN-SUP-P002-003"
      ],
      "scope": "Actual extraction/coverage results; expected case is an assertion, never substituted as an output."
    },
    {
      "test_id": "T2",
      "status": "pass",
      "affected": 88,
      "unknown": 93,
      "confirmed_affected": 0,
      "potentially_affected": 88,
      "rule_ids": [
        "HN-SUP-P005-002",
        "HN-SUP-V4S002-001",
        "HN-SUP-V4S002-002"
      ],
      "scope": "Actual extraction/coverage results; expected case is an assertion, never substituted as an output."
    },
    {
      "test_id": "T3",
      "status": "pass",
      "affected": 140,
      "unknown": 140,
      "confirmed_affected": 140,
      "potentially_affected": 0,
      "rule_ids": [
        "HN-D069-001-001",
        "HN-D069-001-002",
        "HN-D069-001-003",
        "HN-D069-001-004",
        "HN-D069-001-005"
      ],
      "scope": "Actual extraction/coverage results; expected case is an assertion, never substituted as an output."
    },
    {
      "test_id": "T4",
      "status": "pass",
      "affected": 110,
      "unknown": 0,
      "confirmed_affected": 110,
      "potentially_affected": 0,
      "rule_ids": [
        "HN-SUP-S018-001",
        "HN-SUP-S019-001",
        "HN-SUP-S019-002",
        "HN-SUP-S019-004"
      ],
      "scope": "Actual extraction/coverage results; expected case is an assertion, never substituted as an output."
    },
    {
      "test_id": "T5",
      "status": "pass",
      "affected": 0,
      "unknown": 0,
      "confirmed_affected": 0,
      "potentially_affected": 0,
      "rule_ids": [
        "HN-SUP-S024-001"
      ],
      "scope": "Actual extraction/coverage results; expected case is an assertion, never substituted as an output."
    }
  ],
  "errors": [],
  "limitations": [
    "Preliminary model-reviewed output; not legal advice or counsel certification.",
    "Organizer source-byte manifest mismatch unresolved.",
    "20 legal cities unknown. Missing owner/certificate/tenant facts preserved.",
    "Supplemental provenance distinguishes raw official/publisher downloads from browser transcriptions and third-party hosting.",
    "No reviewed cross-source stricter-rule supersession or duplicate consolidation yet.",
    "T2 potential impact is a legal-place change-notification dependency, not confirmed eligibility; individual missing facts stay unknown.",
    "County is recovered geography metadata; supplied rule schema has state/city only.",
    "Court opinion is third-party hosted; direct official final IP25-21 endpoint remains unavailable.",
    "Historical/future snapshots conservative where full temporal validity is not established."
  ]
}


---
# DECISION_LOG.md
# Coordinator response to internal review
All dispositions below are strategy decisions, not completed implementation fixes.

| Finding | Disposition | Reason and next acceptance gate |
|---|---|---|
| T2 internal pass weaker than PDF applicability | Accept | Preserve original report but label notification boundary; separately evaluate eligibility. Zero confirmed remains visible. |
| T1/T3 partial transitions; T4 confirmed is hypothetical | Accept | Per-rule transition assessment and explicit pending hypothetical wording before demo. |
| No precedence or supersession stage | Accept | Evidence-reviewed interactions before one governing cap; unresolved overlap stays visible. |
| Unknown legend conflates failures and facts | Accept | Structured reason taxonomy and regression for each class. |
| 286 predicates mistaken for legal accuracy | Accept | Label model review separately from truth, applicability and measured accuracy. |
| Six answers could hide material conditions | Accept | Shortness is a preference; retain decisive qualification and claim receipts. |
| Handoff unsafe URL/official labels/sample schema | Accept | Adopt philosophy, preserve current safe URL/text rendering; validate a real contract. Do not copy illustrative shortened quotes. |
| Source completeness/date/penalty representation | Accept |87-source ledger, separate raw/transcribed/hosted evidence; audit penalties against schema-compatible outputs. |
| County geography and Santa Ana scope | Accept | County-law coverage disclosed; Santa Ana included in extraction accounting. |
| Stale presentation/two videos | Accept | Reconcile final release and three observed HackOS video requirements. |
| Broad reruns/extra jurisdiction/live monitoring | Defer | Core answer-changing gaps and submission take priority. |
| Spanish view | Conditional stretch | Only after English semantics, actual-data UI and delivery are covered. |
| Perfection/legal certification from reviewers | Reject | Model agreement cannot establish legal truth or organizer acceptance. |

Open disagreement: challenge reviewer suggests UI before precedence repair; evidence and resident reviewers put governing-law work first. Coordinator resolution: define the answer contract first, work on precedence and concise supported prose together, and publish a definitive category conclusion only after its governing-rule gate passes. Unresolved cards can be implemented without selecting a winning rule.

Claude critique pending. Do not automatically adopt it; append specific accept/reject/defer reasons, required evidence and regression cases. No app implementation resumes until that reconciliation is recorded.



---
# REVISED_STRATEGY.md
# Coordinator strategy — candidate for external review

Status: internal review candidate. Implementation paused; Claude critique pending. No promise of perfection. A model disagreement is a signal to inspect evidence, not a vote on legal truth.

## 1. Protect the working baseline
Keep existing source snapshots, API responses, output versions and logs. Record exact reviewed release, hashes, model, date and limitations. Retain canonical rules/lookups/changes contracts. Add the resident explanation as a separately validated presentation layer, not a replacement for legal records. No broad rerun simply to increase the percentage approved.

## 2. Correct claims before improving appearances
Separate reported internal checks from PDF acceptance. T2 currently establishes city-bound potential notification, not confirmed eligibility. Do not claim completed local-ban applicability. Treat 286 approved predicates as model-review outcomes, not 286 correct laws or a measured accuracy percentage. Preserve unknown legal dates, unavailable texts and source-integrity mismatch. Judge-facing metrics must identify fixture checks, offline checks, saved live-model results and observed browser checks separately.

## 3. Close answer-changing legal gaps
Audit the 24 unresolved predicates by rejection reason. Where a missing fact is genuine, compile a conservative expression with an explicit missing-fact reason; do not make dataset residential scope prove primary residence, owner type, detention/care exclusion or certificate date. Where the evidence chain is inadequate, remain source/status/review unresolved. Retrying is justified only by new evidence or a changed compiler approach that addresses a specific rejection.

Prioritize duplicate legal records and state/city precedence for rent caps and just cause. A smaller number is not sufficient to choose the governing cap: jurisdiction, coverage, statutory exclusions and effective dates must all be supported. Any precedence edge needs source IDs, exact support, reviewer result and a test where missing facts block certainty. Preserve secondary sources separately. If no safe resolution is possible within the submission window, the resident answer must explain the unresolved choice, and the submission must list it as a gap.

County geography remains distinct from county-law ingestion. Audit all 87 manifest records by captured, inaccessible, linked-only or superseded/versioned condition; document completeness by source, not rule count. Santa Ana is in corpus scope even though no supplied sample city is Santa Ana. No new jurisdiction or live-monitoring stretch work until core acceptance is addressed.

## 4. Make a resident answer with a claim ledger
Main question: What housing rules apply to my home? Show supplied address selection and the actual saved query date. Six category questions: How much can my rent rise? What rules govern eviction? How much can the deposit be? What application fees are allowed? What can a landlord check? What rules govern rent-setting software?

Each category contains a short answer and any condition that changes its meaning. One sentence is a preference, not a correctness requirement. Do not merge varied rules into a single yes/no status. A category may contain established protections alongside unresolved parts; say that explicitly. Omitted or unloaded law does not mean no protection.

Public reason classes: need property/tenancy fact; legal jurisdiction unresolved; source/status not verified; eligibility logic not reviewed; unresolved overlap/conflict; pending; not yet effective; failed change. Include the most useful supported next fact/question when known, but never promise that one additional fact will settle multiple unresolved issues.

Each material sentence has support IDs. Check my homework opens only its supporting receipts: exact quote, citation, source URL, retrieval date, query date, verified effective date/status, limits and conflict. Geography and property-data claims cite their own inputs, not a law that does not establish those facts. Source hash disagreement is available in the audit; answer-changing limitations are visible with the answer.

## 5. Validate translation separately
Generate explanations from frozen evidence and results, with an independent semantic review. Check subject, trigger, jurisdiction, threshold, dates, exemptions, operative status and lack of fabricated applicability. Mechanical support-ID existence alone does not establish semantic support. Reject unsupported summaries instead of polishing them. Useful translations remain conditional where evidence is conditional.

Regression cases: reviewed predicate but missing owner/CO; unreviewed predicate with complete sample data; uncertain city; multiple local/state caps; pending proposal; future enactment; failed ballot; mixed known/unknown category; source unavailable. Plain-language fallback is specific and short. Optional Spanish only after English passes, with the same evidence ledger and semantic checks.

## 6. Verify the real screen and release
Test actual 500-address saved data, date switching, scoped homework, keyboard/mobile, unknown reason classes and T1–T5 details. Existing fixture browser proof is useful but does not prove production data/browser deployment. Keep full details and audit accessible; remove raw engine prose from the initial resident view.

## 7. Deliver and demonstrate
Reconcile method note/deck/scripts with final evidence, not older counts. Create GitHub-ready review records; verify actual public repository permissions and deployed Render URL. Three <=60-second videos: human introduction; product story (answer, homework, change); technical walkthrough (automated extraction, geography, conservative eligibility, evidence and reproducibility). Complete HackOS and linked Google Form before9AM EDT Oct4; confirm receipts. Reserve at least90 minutes for recordings, uploads, permissions and recovery. External review is timeboxed to one critique and a documented response; no endless review loops.

## Completion standard
For every PDF/slide requirement: attach observed evidence or a named remaining gap. A release can be usable with honest unknowns; it cannot be called complete by renaming failed eligibility as notification success. No counselor certification, safety guarantee, evaluator score or measured legal accuracy is claimed without corresponding evidence.



# Additional internal findings
Evidence reviewer reran40offline tests PASS and reproduced four500-address outputs exactly; no substantive verification of every quote/paraphrase. Default counts22,650unknown/9,215applies/979future/440pending; zero superseded. Counts are not accuracy.211of310effective dates null; no dedicated penalty field (penalties may be separate rules/prose; supplied schema lacks field). Latest provenance repeatedly records organizer hash mismatch; repeat records aren't unique documents. T1/T3 acceptance uses at least one applicable transition per address, not every selected rule. T4 confirmed count is hypothetical.24 unresolved eligibility records.
Resident reviewer found generic Unknown legend misleading: missing fact differs from failed legal review. Six category summaries cannot choose first/highest confidence/lowest cap. Preserve actor, event and exceptions. Bill X-ray reusable renderer lacks URL protocol filtering and calls all sources official; its receipt schema file is a sample object, not formal schema; date inheritance mismatch and abbreviated illustrative quotes must not enter exact evidence. Adopt the philosophy with current safeUrl/textContent/exact-span safeguards. Existing browser verification covers fixtures; user actual screenshots establish loaded page, not entire release behavior.
Challenge reviewer flagged stale engine2.1 presentation and two-video instructions. Actual observed HackOS requires three<=60-second files and both submissions. Include Santa Ana extraction even with no sample properties. County geography is not county-law completeness. Proposed confidence numbers are model outputs, not legal correctness probabilities.
