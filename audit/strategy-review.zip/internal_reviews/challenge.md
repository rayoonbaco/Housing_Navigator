# Challenge coverage red-team review

Review timestamp: 2026-10-04 UTC. Role: independent challenge/delivery reviewer. Scope: offline inspection only; no engine/app changes, new API calls, deployment, or submission. This is a strategy critique, not legal review or evaluator scoring.

## Evidence inspected

- `challenge/participant-final-no-hour16/mit-rental-housing-law-navigator-challenge-v5-participant-no-scoring-no-hour16.pdf`, all six pages (text extracted with `pdftotext -layout`).
- Same directory: `README.md`, `schema/rule_record.schema.json`, `dev/change_tests.json`.
- `latest-four/engine-v2_3/20261004T023146-7b62feda/report.json`, `rules.json`, `lookups.json`, `changes.json`.
- `latest-four/demo-v3/RETURN_SUMMARY.md` and `presentation/submission_v3/official_verification.md`.
- `latest-four/sources-v4/supplemental_sources/county_layer/COUNTY_LAYER_AUDIT.md`.
- Current HackOS requirements below were supplied as coordinator-confirmed screenshot findings; this reviewer did not independently view those screenshots.

## Decision

Proceed toward a resident-first release, but do not describe the product as legally complete, all challenge tests passed, or 286 legally verified answers. The present release demonstrates automated extraction, conservative unknown handling, linked evidence, legal-place resolution, and reproducible date/change snapshots. Its greatest substantive task gap is cross-rule precedence; its greatest product gap is too many raw legal records before the reader gets an answer; its greatest submission risk is using stale presentation requirements and counts.

The challenge's primary question is “which rules apply here today,” not “which extracted records could be related to this address.” Humanization is therefore essential, but cannot substitute for determining which overlapping protections govern.

## Inspected facts versus stronger claims

Latest report: 310 rules, 286 approved coverage predicates, 24 unresolved, all 500 addresses, 10 new calls in this pass, estimated $1.76364, no run errors. Those are reported outcomes, not counsel certification. Reading saved default lookup output produced 22,650 `unknown`, 9,215 `applies`, 979 `not_yet_effective`, and 440 `pending` entries, with **zero `superseded` entries**. Thus roughly 68% of returned default rule/address entries are unknown. This percentage is NOT a property-level accuracy score; an address can have both known and unknown rules.

All six categories and state/city rule levels appear. 211 of 310 records have no effective date. Null dates are honest where evidence is absent, but strengthen the need to qualify historical/future snapshots. No record has a dedicated `penalty` property. The PDF requests penalty capture, but supplied JSON schema does not define that property; penalties may exist in extracted requirement text or separate rule records. A field absence is not proof that penalties were omitted, so add a completeness audit before claiming penalty coverage.

Report T1-T5 statuses all say pass. T2 has 88 affected addresses, **zero confirmed affected**, 88 potential affected, 93 unknown. PDF p4 says local bans apply only inside city limits; dev test refers to local rule applicability. The current internal test's potential-notification interpretation is useful and disclosed, but is a weaker test than proving local ban eligibility. Label it “boundary/change notification check passed; individual coverage unresolved,” never just “T2 passes.” T1 and T3 each also retain unknown entries despite confirmed change notification sets. T4's all-MA affected set is hypothetical pending legislation, not operative protection. T5's empty set correctly demonstrates a negative finding, assuming failed source status remains supported.

## Prioritized gaps and acceptance gates

### P0: Preserve the distinction between legal answer, missing data, unreviewed interpretation, and possible change

The resident view must not present all unknowns as missing building information. The 24 unresolved predicates represent interpretation/review gaps, whereas approved predicates can still yield unknown due to unavailable facts. Missing city, missing owner/occupancy facts, source integrity concerns, disputed dates, and incomplete precedence are different causes requiring different messages.

**Acceptance gate:** Every category card derives from linked rule IDs and lookup results. Applies, fact-dependent, not-yet-effective, pending, failed, conflict, source unavailable and unresolved-review states are kept distinct. A card cannot assert a protection if only unknown evidence supports it. “No applicable rule found in the reviewed sources” is not “there is no law.” Conditional claims preserve conditions and dates. Empty categories disclose corpus coverage limits.

### P0: Correct the submission package now, before recording

Demo-v3 is visibly stale: it inspected engine 2.1, says T1 fail/T2-T3 not_run, and expects two videos based on older FAQ. Current coordinator-confirmed HackOS screenshots require three uploaded videos—team introduction, product demo, technical walkthrough—each MP4/MOV <=60 seconds and <=1GB, plus valid GitHub repository link, photo JPG/PNG/WebP <=10MB, and two submissions (HackOS and linked Google Form). Deadline 9AM October4 Eastern, grace to9:15; plan before9. A public app URL is valuable even where exact required marker is uncertain.

**Acceptance gate:** Final scripts, method note, deck, README, requirement map, and app banner all describe the same release. Three real files watched end-to-end and durations checked. Final GitHub link accessible to judges, app link tested independently, JSON files and one-page method note included, both form submissions have retained receipts. Do not present older presentation smoke tests as current UI/legal tests.

### P1: Cross-rule precedence and duplicate handling before a single headline cap

README section5 defines `superseded`; PDF p1/3 asks state/local overlap and precedence, particularly rent caps. Report admits no reviewed cross-source stricter-rule supersession or duplicate consolidation. The saved default output has zero superseded results. A six-card summary selecting a visually neat cap without reviewing precedence could introduce a serious regression.

**Acceptance gate:** Targeted evidence-supported precedence relationships, not generic “city wins,” with property/date coverage independently established before superseding. Where unresolved, display both rules and the conflict clearly, avoid a single governing cap. Test an applicable local/state overlap, a local exemption where state still applies, unknown local coverage, and before/after date cases. Deduplicate display by supported provision identity while preserving every source/record and amendment lineage in the audit.

### P1: Strengthen local-ban semantics without forcing approval

Three targeted predicates remain rejected because primary residence/exclusion evidence cannot be inferred from generic residential dataset status. Do not repeatedly ask a model to approve the same inference. Missing facts can be represented as missing facts within an otherwise reviewed predicate, but legal definitions/exclusions must be supported first.

**Acceptance gate:** Reviewer checks supported primary-residence and care/detention/owner/agent conditions; evaluator receives only public or explicitly user-supplied facts with provenance. Unknown remains unknown when a required fact is absent. Boundary checks exclude Newark and unresolved legal cities. If needed preserve the weaker notification check while openly stating T2 eligibility not resolved.

### P1: Explain like neighbors, preserve claim-level support

The PDF makes plain-language explanations part of required Module B/Explain, while English/Spanish renter-facing view is a stretch goal. Schema `requirement` is one or two plain-language sentences. The existing record volume overwhelms the task. “Check my homework” should reveal the support for the exact human statement, not merely a source homepage.

**Acceptance gate:** One category heading + one concise answer + necessary qualification; expandable exact passage, official citation/link, retrieved/as-of date and decision boundary for each material claim. Explain “unknown” as an action or reason when known. Text condensation independently checked against supporting evidence for omitted exceptions, dates, numbers and actors. Numeric caps/formulas must not be invented from unavailable facts. English/Spanish only if both are reviewed and tested; no pretending machine translation is validated legal equivalence.

### P1: Corpus completeness and provenance ledger

54 supplied captures do not establish completion of all87 sources. 33 link-only/access gaps and D056 capture-status inconsistency need an explicit disposition ledger. All organizer-byte hash mismatches remain unresolved: a separately pinned snapshot proves reproducibility of inspected text, not original integrity. Santa Ana has laws but no sample addresses, so it must remain represented in extraction coverage rather than being dropped due to address absence.

**Acceptance gate:** For each87 source ID, captured/linked/unavailable status, terms/access decision, extraction outcome, rejection reason, raw/transcribed/third-party host distinction, retrieval date, original hash versus actual hash. Rule-level exact evidence gate remains unchanged. Show completeness as known/unknown, not a blanket full-corpus success.

### P2: Legal stack, arbitrary queries and temporal boundaries

County stack is required by PDF, but supplied rule schema/corpus allow state/city only. Existing county geography is a sound response; do not invent county legal rules or schema enums. All500 addresses must remain present even when city unknown. “Any apartment address” appears in introductory aspiration; minimum evaluation scope explicitly uses sample addresses. Four saved dates meet supplied test dates, but do not imply a live arbitrary-address/any-date service.

**Acceptance gate:** App clearly states sample scope and available as-of dates. Legal city versus mailing city visible on inspection. Unknown city cannot inherit postal-city ordinances. County layer shows geography/provenance and county-law coverage limitation. If arbitrary dates/addresses are added, use the same pipeline and actual data retrieval, not nearest saved snapshot presented as current law.

## Efficient refinement order

1. Freeze current release with hashes and truthful baseline evidence.
2. Agree claim semantics, missing-fact taxonomy, precedence risks and release acceptance gates through this red team and external Claude review.
3. Implement a resident front page over preserved audit detail; targeted claim explanation review, not fresh whole-corpus reruns.
4. Target precedence and a small number of consequential unreviewed coverage issues, using full linked evidence and explicit expected outcomes.
5. Reproduce critical cases and exact output consistency; test responsive/keyboard flows using final data, not fixtures alone.
6. Publish early enough to test evaluator-accessible URLs; update docs and record three final videos from actual release; submit both forms before9AM.

Budget permission is not a reason to repeat the 300-rule interpretation process. Pay for bounded comparative critique or a necessary targeted repair, with logged inputs, outputs and disposition. Broad live updates, new jurisdiction and Spanish are stretch work; prioritize correctness, readability and submission first. A documented refusal to guess is stronger evidence than manufacturing a fully green dashboard.

## Judge-facing framing

Safe: “We extracted structured rules automatically, preserved exact source evidence, reviewed coverage logic separately, and show where missing facts prevent an answer.”

Unsafe: “All rules legally verified,” “100% accuracy,” “all five organizer tests fully passed,” “286 protections apply,” or “we cover every county law.”

Do not infer numerical weights from the v5 filename or a removed scoring appendix. Any photographed scoring slide is a distinct authority that the coordinator should transcribe and reference separately. This reviewer did not inspect those images and therefore assigns no percentages. No hosting/model sponsor mandate is established by the documents inspected.

## Coordinator baseline assessment

Inspected `review/strategy-v1/BASELINE.md` after drafting this critique. The baseline is substantially honest and aligned with this review, particularly T2 qualification, snapshot rather than live scope, missing facts and precedence risk. Recommended refinements:

- Explicitly include penalty completeness and Santa Ana extraction-only coverage in the acceptance map; neither should disappear when designing around six resident questions and nine sample cities.
- Preserve a compact visible confidence/limitation statement, but do not display model confidence as a probability of legal correctness.
- Treat “strictly one sentence” as a design preference, not an acceptance rule; an important exception can justify a second concise sentence.
- Export the requirement map with columns requirement authority/page, implementation evidence, actual test type/date, gap, release acceptance gate. This prevents upstream fixture checks, current Windows tests and inferred legal claims blending into one PASS count.
- Have external Claude challenge the strongest product headline and unresolved-precedence handling rather than just polish the strategy. Ask it which remaining gap can cause a materially wrong answer, which can remain disclosed, and which claims should be removed from the demo.
