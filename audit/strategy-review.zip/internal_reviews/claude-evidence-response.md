# Evidence red team response to external Claude critique

Reviewed: `review/claude-return-2/20261004T033325Z-d6dbee12/CLAUDE_FEEDBACK.md`. Basis: actual engine-2.3 files and source/code checks documented in `evidence.md`, with a fresh count of T3 flags and inspection of saved T3 notes. No model calls or product code changes.

## Accept

- Correct the broad 5/5 narrative. T2 establishes 88 potential local notifications and no confirmed eligible properties; preserve internal receipts with explicit scope rather than implying full PDF applicability.
- Present model-reviewed counts as process evidence, never legal accuracy percentages. Missing facts and rejected compiler outputs need distinct reasons.
- Preserve conditions, unresolved precedence, as-of limits, future/pending/failed separation and source capture classes. Reconcile stale presentation counts before recording.
- Freeze the baseline, reserve 90 minutes for delivery, prioritize bounded fixes over a general rewrite, and defer Spanish/extra-jurisdiction/live-monitoring work until core delivery passes.
- Adopt claim-level receipts with safe URLs and literal text; Bill X-ray's provenance design is useful without indiscriminate code imports.
- Test actual saved-data UI behavior, jurisdiction mismatch, unknown cities, Newark exclusion and public deployment independently of fixture browser tests.

## Change or correct

1. **T3 conflict flags already exist.** `changes.json::T3.conflict_flag_address_ids` has 88 entries. Its notes cite FAIR §§3–6,9, municipal competing requirements and carveouts, and explicitly say this is possible overlap, not municipal invalidity. Lack of general precedence does not mean lack of the PDF's requested possible-conflict flags. Further verification is appropriate; implementing a new flagging layer is unnecessary solely to answer Claude's uncertainty.

2. **Do not label every legal claim “unverified.”** That erases genuine distinctions between an exact quoted supported statement, a model-reviewed conditional scope, a missing building fact and a rejected claim. Use stage-specific labels: source snapshot matched; legal paraphrase model-reviewed; coverage reviewed but facts unknown; evidence unresolved; precedence unresolved. None means counsel certified. Keep the 286 predicates rather than blanket invalidation; reprioritize concrete counterexamples for review.

3. **Mechanical checks cannot replace semantic review.** Quote/date/status/ID checks are valuable deterministic gates, but a paragraph can pass every mechanical check while reversing an exception, broadening “may” to “must”, changing the liable actor or implying a transaction happened. Keep separate semantic comparison against original evidence, including adversarial actor/scope/exception/date tests, and label a model pass as a model assessment rather than measured truth. Mechanical and semantic checks complement each other.

4. **Narrow precedence work is reasonable; a hand-authored production legal overlay is not the default.** User/challenge insist on automated rule extraction. A human source audit may support a narrow relationship benchmark, but do not create governing-law edges manually and call the pipeline automated. Prefer evidence-derived candidate relationships with independent review; if no qualified relationship is available, retain unresolved overlap. Always preserve original records and explain the selected relationship.

5. **T2’s five additional unknowns are explained by saved geography.** The 88 potential set requires a resolved Hoboken/Jersey City match. Five NJ addresses with unresolved legal city can carry unknown local candidates, hence 93 unknown; they are excluded from the resolved notification set. Do not suggest the 88 were inferred from mailing city. Twenty is the full three-state unresolved-city total, not the T2 count.

6. **MA replacement wording is too broad.** Claude proposes saying other Massachusetts law is outside what was loaded/reviewed. It is loaded: rules include `HN-D048-001-001` Chapter 40P's statewide municipal-rent-control prohibition and additional related records. Safer: “This failed ballot question creates no rent cap; this result alone does not establish every rule governing your home.” Describe Chapter 40P separately with its own evidence and qualifications.

7. **99 non-null dates is not verified date completeness.** 211 null dates matter, but null can be the correct conservative representation. The default snapshot can support in-force status without proving an exact historical operative date. Show “exact start date not established” and the actual snapshot basis; do not imply that a null date automatically invalidates all default-date evidence.

8. **Do not cut receipts entirely.** Exact-source inspection is central to both the challenge and the user's Check My Homework goal. A narrow receipt view for every material displayed sentence is higher priority than a broad taxonomy or ambitious precedence engine. Reuse existing evidence panels where possible.

9. **Human review is not the only possible accuracy measurement, and human judgment is not automatically ground truth.** A validated benchmark with explicit expected outcomes can measure defined behaviors; domain reviewers can audit substantive interpretation. Report benchmark accuracy and domain-audit scope separately. Neither current model consensus nor 40 passing mocked tests measures broad legal accuracy.

## Recommended synthesis

Keep Claude's conservative scope and delivery discipline. Correct the known factual uncertainties using saved files. Build a compact resident interface around evidence-supported claims, with an honest reason when an answer cannot be determined. Fix the particular eligibility-compilation defects and review a narrow governing-law example only if supported by evidence. Retain deterministic guards plus semantic review, original receipts and the distinctions between notification, hypothetical impact and confirmed coverage. Do not trade a misleading all-green dashboard for an equally misleading all-unverified dashboard.
