# Internal red team — evidence, applicability and claims

Review date: 2026-10-04 UTC. Reviewer: independent internal evidence-review agent. This is an engineering critique of saved files, not counsel review or legal certification. No external API calls were made, no source access was attempted, and no engine or application files were edited.

## Material reviewed and checks actually performed

- Challenge PDF: `challenge/participant-final-no-hour16/mit-rental-housing-law-navigator-challenge-v5-participant-no-scoring-no-hour16.pdf`, all six pages converted to text and read.
- Latest saved return: `latest-four/engine-v2_3/20261004T023146-7b62feda`, including report, rules, coverage, provenance, jurisdictions, lookups and the three latest coverage rejections.
- Evaluator and change-test implementation: `deliverable/Housing_Engine_v2_3/evaluate.py` and `run_next.py`.
- Re-ran the existing offline suite with `python3 -X utf8 -m unittest -q`: **40 tests passed**. These are mocked/offline regression checks, not a new live legal review.
- Recomputed all 500 address results from rules, saved predicates and saved geographies at each of four supplied snapshots; each output matched its saved lookup file exactly. Each snapshot contains 33,284 returned rule-address records.
- Independently counted 310 unique rule IDs, six categories, 286 saved coverage predicates, 500 addresses, 480 county/place matches and 20 unresolved legal cities. Default-date row totals: 22,650 unknown, 9,215 applies, 979 not-yet-effective, 440 pending.
- Saved rules have nonempty URLs and quoted spans, but this review did **not** substantively inspect or independently verify every quote and legal paraphrase. 99 records have a non-null effective-date field; this is not a certification of their precision or correctness.

## Overall judgment

The saved pipeline has useful deterministic reproducibility and deliberately conservative safeguards. It is not yet equivalent to a complete address-level answer to the challenge. The priority is to resolve the difference between a transparent set of extracted records and a usable statement about the governing law. A larger number of model calls or more reviewed predicates alone does not resolve this difference.

There are two separate goals: trustworthy resident answers and the challenge's deterministic change assertions. Their evidence must remain separate. Unknown is explicitly allowed by the PDF when facts are missing; unknown due to failed evidence/compilation is a different limitation. Neither should be disguised by a concise design.

## Prioritized findings

### P0 — “5/5” is narrower than the PDF's T2 statement

The PDF page 4 says T2 applies each local ban only within its own city, excluding Newark. `run_next.py::changes` now includes unknown records in the affected set when a resolved legal city matches a selected ban. Its pass assertion checks that this notification-dependency set equals resolved Hoboken/Jersey City addresses; it does not require confirmed application. Latest report: T2 passes with **88 potentially affected, zero confirmed affected, 93 unknown**. The 93 include unresolved-boundary candidates; the 88 do not.

This is a defensible potential notification workflow, and the notes disclose it. It is not sufficient support for “all five legal applicability tests pass.” A judge could reasonably view it as moving the acceptance criterion. Preserve the existing receipt, but name its scope as a boundary/notification check and show a separate eligibility assessment. Missing property facts remain unknown rather than being invented to make the PDF assertion green.

**Gate:** In documentation, UI and video, any 5/5 statement must identify the scoped checks. T2 must visibly retain potential/confirmed counts and why eligibility is unknown. Do not change rules or facts merely to match expected address counts. A targeted predicate repair must address primary-residence intent and excluded facilities, and carry the required owner/agent exemption evidence, then pass independent review without optimistic dataset-label inference.

### P0 — No cross-source precedence means no single governing rent-cap answer yet

PDF pages 1 and 3 explicitly require handling overlap, supersession and local-versus-state precedence. The latest report explicitly says no reviewed stricter-rule supersession or duplicate consolidation. All 310 `overrides` fields are empty. `lookup` evaluates each record independently; it has no stage applying overrides or comparing governing caps. Merely returning local and state statements together cannot tell the reader which governs.

**Gate:** Before a category summary chooses one cap or suppresses one rule, establish an evidence-backed relationship using complete coverage, dates and any statutory savings/preemption language. Test a covered local building, a state-only building, an exempt building and an unknown building. If unresolved, show the competing conditional statements and say the governing limit needs verification. Do not select the numeric minimum automatically: exceptions, property coverage and authority determine which comparison is valid.

### P0 — Plain language must not convert conditional duties into promises

Existing `lookup` appends a caveat for applies results: the cited requirement still governs its transaction/event conditions. Some returned rules describe a court or agency duty, not a protection exercisable by every resident. The evaluator treats dataset apartment scope as limited contextual evidence, and lacks owner, tenancy and transaction fields. Those limits matter when condensing 121 eviction-category records or 60 deposit-category records into six resident answers.

**Gate:** Build claim-level prose linked to rule IDs and supporting spans. Preserve actor, action, trigger, building/tenant prerequisites, date and exceptions. A broad paragraph containing several legal claims needs several evidence links, not one source link that only supports its first sentence. A plain claim must not imply a violation happened merely because a conditional duty exists. The “Check my homework” expansion must reveal source URL, exact passage, retrieval and query dates, plus the facts used and the facts still missing.

### P1 — Evidence and coverage states need separate names

286 independently model-reviewed predicates do not mean 286 universally applicable protections. A predicate containing explicit unknown nodes may be correctly reviewed and still produce unknown. Three new targets failed review because dataset residential scope does not prove primary-residence intent or exclude care/detention uses. Another rejection also identifies an exemption copied from a rule record without the appropriate definition evidence. These are useful failures, not successes to erase.

The current final string “Coverage compilation did not pass independent review” conflates missing/rejected/uncertain compilation. Conversely, an unknown node may describe a permanently missing property fact. UI copy “we need one more detail” is justified only if that specific detail can actually resolve the relevant tree and the legal evidence is sound.

**Gate:** Distinguish (a) unverified legal source or compilation, (b) missing property/tenant facts, (c) unresolved geography, (d) unresolved legal relationship, (e) unknown date. Give the resident a feasible next question only for (b), without asking for sensitive unnecessary details. Asking a tenant's age or disability is not a default substitute for unresolved evidence.

### P1 — Temporal validity and conflict tests are incomplete

`date_status` permits an effective start date but no repeal/end validity interval. Without a precise start it allows in-force status only at the default 2026-10-01 snapshot; other dates become unknown. That conservatism is preferable to fabrication, but “as of any date” is not currently delivered. A start date alone is insufficient if the rule was later amended/repealed. Jersey City adopted amendments do not establish a publication-based exact operative date.

For T1 and T3, current acceptance requires at least one applies record after and at least one not-yet-effective before for each state address; it does not assert every selected rule's transition. Both runs can have confirmed and unknown simultaneously (T1 250/250; T3 140/140). For T4, the `confirmed_affected` field merely duplicates a hypothetical pending set: 110 are not confirmed present protections. T3 potential conflict flags include uncertain local applicability; they are not adjudicated invalidity or preemption.

**Gate:** Record per-rule start/status assertions and separately report complete versus partial transition evidence. Label T4 as hypothetical, including any count field displayed. For conflict summaries cite both competing rules and the unresolved interaction. Keep historical/future uncertainty visible; do not extrapolate default snapshots.

### P1 — Source coverage and provenance need an honest denominator

The supplied inventory is 87 sources, with 54 captured texts; D056's claimed capture is absent, and 33 link-only sources require access review. Latest rules reference 47 distinct `source_doc_id` values including supplements; that is not a document-read completeness metric. A document can produce zero accepted records, be out of scope, be inaccessible or fail validation; these cases require distinct ledger outcomes.

295 latest rule-level provenance records contain `manifest_hash_match: false`. Those include repeated rules from shared files, not 295 different failed documents. Pinning bundled text and validating local quote substrings establishes repeatability of that snapshot; it does not explain the organizer-byte mismatch or certify original-source integrity. Some supplements are browser transcriptions, while other captures are retained official bytes or third-party hosted court text. Do not flatten these evidence classes.

**Gate:** Produce a source ledger for all 87 plus supplements: access/capture type, extraction outcome, zero-rule reason, accepted/rejected counts, snapshot hash and original-manifest status. Accept new sources only through existing automated extraction and evidence review. Do not repeat broad acquisition if a rejected scope predicate only needs an explicit unknown and correctly linked definition.

### P1 — County and penalty expectations are only partially represented

PDF page 2 expects a state/county/city stack; supplied schema supports only state/city levels. 480 county names/GEOIDs are present from saved Census geography. This satisfies part of resolve but not county-law coverage. There must be an explicit source/schema interpretation, not an invented county rule or an assertion that no county rules exist.

PDF Module A requests penalty capture. There is no dedicated `penalty` field in any of the 310 saved records. Penalties may be represented in prose or separate extracted rules, so field absence alone does not prove missing penalty evidence. However a judge cannot easily verify structured penalty completeness.

**Gate:** Map the PDF's penalty expectation to actual schema-compatible representation with samples; disclose any unavailable fields. Document county geography versus corpus law scope. Do not silently extend the required schema in a way that invalidates submission outputs.

## Recommended efficient sequence after strategy approval

1. Freeze and hash this baseline; retain its original scoped receipts. Create an acceptance matrix in which every claimed pass has an evidence path and scope.
2. Review the high-impact category-summary contract before writing UI: one claim can cite several records, and multiple claims must keep separate evidence maps. Bill X-ray's expansion pattern is appropriate if adapted to legal prerequisites and uncertainty.
3. Repair only targeted eligibility compiler errors using already-held evidence and explicit unknown nodes. A reviewed unknown predicate is a legitimate outcome; it will not make all affected residents confirmed.
4. Establish or honestly defer precedence for the rent-cap examples used in the demonstration. Choose examples based on actual verified outputs, not on theatrical convenience or expected counts.
5. Run adversarial resident-answer checks for uncertainty, future/pending law, conflicting rules and boundary errors. Record each check's fixture/live/saved-data scope. Independent models may assess interpretation, but they do not replace source validation.
6. Update the method note and videos to the actual release. Exclude claims of exhaustive coverage, perfect legal accuracy, counsel review, production monitoring or universal dates unless those abilities have been demonstrated.

## Strategy critique

The proposed human-first view is the right next product direction. It should proceed only after the review defines what information may be condensed and what qualifications cannot disappear. “Six short answers” is a presentation target, not an acceptance criterion that every category must always resolve to one definitive sentence. A compassionate answer can be short while honestly saying, “This rule may protect you; we cannot confirm whether your building qualifies.” That wording still requires evidence for the rule and a precise explanation of the unknown.

A second-model critique can expose blind spots and deserves documentation. It is not statistical independence if both models inspect the same incomplete source context or anchor on the desired outcome. Send it the challenge text, actual scoped report, relevant code/receipts and unresolved evidence—not just our polished strategy. Ask it to find a concrete counterexample and a testable repair. Preserve its raw response, model/version and timestamp, then record which proposals we accept, reject or defer and why. Never describe model consensus as legal verification.
