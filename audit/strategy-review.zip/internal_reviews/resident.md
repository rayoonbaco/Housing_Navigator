# Independent red-team review: resident experience and claim-level evidence

Review date: 2026-10-04 UTC. Scope: inspect actual saved UI code/data, the uploaded Bill X-Ray handoff, and five user-supplied slide photographs. No application code or production records changed. This is a strategy/code inspection, not a resident study or a new browser test.

## Verdict

Keep the evidence engine and audit viewer. Add a resident-first view whose primary unit is a practical question and a supported answer, rather than a rule record. Do not implement this as merely renaming Unknown and trimming explanation strings: that would hide distinct uncertainty causes and could select the wrong controlling law.

The proposed direction is sound, but needs three hard constraints: (1) claim-to-source validation including material exceptions, (2) reviewed consolidation/precedence before publishing a category conclusion, and (3) explicit distinction between missing resident facts and missing/unreviewed law evidence. A red team and another model can improve the strategy; neither establishes legal truth or perfection.

## Direct evidence inspected

- `upload/03-IMG_3059.png` (slide 9/9): home-protection law must be readable to its residents; every answer traceable to its source.
- `upload/06-IMG_3055.png` (slide 6/9): Extract -> Resolve -> Apply -> Explain -> Track change. Explain explicitly includes plain language, quoted source, and as-of date. Apply includes year built, unit counts and exemptions. These are system duties, not five chores for a resident.
- `upload/07-IMG_3054.png` (slide 5/9): illustrative compact address/context panel plus six concise category answers and statuses, including a state-cap supersession example. Its footnote says illustrative lookup, as of Oct 1, 2026. These are layout/behavior requirements, not verified production answers to copy.
- `upload/05-IMG_3056.png` (slide 7/9): missing year built, mailing city != legal city, enacted != in effect, pending != law, struck != law, stricter rule wins. A condensed screen must retain these distinctions.
- `upload/04-IMG_3057.png` (slide 8/9): 75 script-scored points (extraction 25, address coverage 20, citations 15, changes 15); 25 demo points (plain language 10, responsible design 10, scale 5). Transparency requires source/date for every rule, as-of, pending separate, unknown instead of guessing; no legal advice or evasion guidance.
- `review/bill-xray/Bill_XRay_Housing_Handoff/HANDOFF.md`, writing prompt, implementation status and examples: supported meaning first, claim receipts below, missing evidence not nonexistent law; paragraph support IDs and scoped Housing drawers proposed.
- Current `integration/release-candidate/ui/index.html`, `app.js`, `data/lookups.json` and reusable Bill X-Ray renderer/schema sample.

## Findings and priorities

| Priority | Finding | Evidence | Required strategy change |
|---|---|---|---|
| P0 | Unknown is falsely described as always missing property facts | `index.html` status legend says "needed property facts are missing"; saved `lookups.json` has Unknown with "Coverage compilation did not pass independent review" and incomplete legal exceptions | Introduce internal structured reason categories; display "We need a detail about your home" only for actual missing facts. Display "We have not verified this answer yet" for review failures and "We could not confirm the city's rules" for geography. |
| P0 | One category can have many rules, distinct conditions, dates, and authorities | `renderCategory()` renders every rule; A0001 has 73 saved results, including multiple near-overlapping screening, deposit and rent rules | A category summary needs its own supported claim ledger and reviewed selection/precedence. Never choose the first rule, highest confidence, any Applies, or the lowest numerical cap without checking same scope, date and exceptions. |
| P0 | Condensation may convert a rule about a conditional event into a claim about the home | Saved explanations distinguish property scope, screening events, tenant disability/animal facts and owner exceptions | Separate "what the rule says if this happens" from "what we know about this home." Do not infer that eviction, denial, rent increase, deposit request or tenant characteristic occurred. |
| P0 | Missing results cannot mean no protection | UI currently correctly warns empty category != no restriction; Bill X-Ray doctrine matches | Preserve the distinction in short prose. Do not produce DOES_NOT_APPLY or "No protection" from omitted/empty output. No category answer is a certification of full legal coverage. |
| P1 | Main screen exposes machinery before the answer | Current hero describes "supplied housing rules the engine returned"; address panels show IDs, dataset, benchmark, vintage, GEOIDs; each rule shows internal IDs and full engine explanation | Main view: address, date, brief location confirmation, six practical question cards. Keep original postal and matched geography provenance in an expandable address-details area and audits separate. |
| P1 | Source status and personal applicability can be blended in friendly language | Current UI has two separate badges per rule; handoff recommends answer-level statuses | Preserve two dimensions internally. Public future/pending wording must say when/if a change could matter; no green protection badge for a pending bill or a future statute today. |
| P1 | Quoted source alone is not enough to substantiate simplification | Handoff proposes support IDs; current UI simply displays rule.quote plus reviewer notes | For each material sentence map exact supporting spans, rule IDs and limitations; independently check semantic entailment, date, scope, numeric thresholds, actor and trigger. Presence of IDs is a structural check, not proof of meaning. |
| P1 | Broad claims of browser/readability verification would overstate this review | Existing upstream fixture browser checks are not a test of new prose or current production summary | After implementation run actual-data browser tests and a timed human comprehension check. Label fixture versus production, structural versus semantic, and model review versus actual user evidence separately. |

## Refined resident strategy

### Main screen contract

Lead with "What housing rules apply to my home?" and choose a supplied address and evaluated date. Avoid "Any address" unless real arbitrary-address resolution and evaluation are implemented. Use six practical questions: rent increases, eviction, deposit, application/screening fees, screening protections and rent-setting software. Each card should have one short main answer, at most one short qualification needed to interpret it, a visible date/status, and **Check my homework**. This is six topic answers, not a promise that each topic has exactly one governing legal rule.

Good prose structure: practical supported meaning -> decisive condition -> unresolved fact/exception or date. Prefer 20-45 words as an editorial target, not a forced limit when an exception would be lost. If multiple rules cannot be safely condensed, say so simply and expand related rules. Do not bury a condition that changes applicability solely inside a citation drawer.

Supported generic uncertainty copy (not housing-law conclusions):
- Missing fact: "We need to know [specific fact] before we can tell whether this rule covers your home."
- Unresolved law review: "We found a rule about this, but we have not verified enough to give you an answer yet."
- Conflict: "Two rules may matter here. We have not confirmed which one controls."
- Empty source coverage: "We do not have a verified answer for this topic in the sources checked."
- Future/pending: show actual verified date or pending status; do not fabricate one from retrieval date.

### Claim and answer contracts

Additive derived answer artifacts should preserve all original engine outputs and their hashes. Each answer should store address ID, query as-of, topic, ordered supported claims, status reasons, source-rule IDs, controlling-rule decision and grounds, applicable conditions/exceptions, unresolved facts, and citations. Include run ID/model/prompt provenance when AI writes or reviews prose.

Each material claim maps to one or more exact evidence spans and supporting rule IDs. A sentence containing multiple factual assertions either maps each assertion separately or is split. A category headline like "Your deposit is capped" is itself a claim and must be validated. Statements about known property facts map to their data provenance, rather than a legal citation. No assertion of a specific outcome from a source that only establishes authority or a possible remedy.

**Check my homework** must be scoped to this card's claims. Show claim -> legal citation/source link -> exact expandable span -> scope/exception limits -> verified effective/as-of/retrieval dates -> conflicting authority if relevant. Missing dates remain "not verified," never a made-up current-law check. Hash mismatch/integrity gaps remain accessible with clear authority labels. Do not label secondary guidance or mirrored court material "official source" automatically.

Ask the highest-value missing fact only after a reviewed predicate establishes that answering it can change eligibility. Do not collect sensitive household facts merely to make the prototype look complete. User-entered facts are unverified scenario inputs, separated from assessor/Census facts and public benchmark outputs. Keep sample evaluation reproducible.

### Consolidation before certainty

Duplicate summaries can be combined only when their law, scope and dates match. A local stricter-rule conclusion needs reviewed evidence of interaction/authority plus established property coverage, not the slide's illustrative example. Keep distinct landlord duties, tenant protections and government implementation duties separate. A statewide proposal or failed ballot question may appear in a changes section but must not become a current protection. Potential notifications remain potential, not personal entitlement.

## Reusable handoff cautions

1. `reusable/housing_receipt_schema.json` is a sample object, not a machine-enforceable JSON Schema. It lacks formal required/type/enum constraints; build a real validated contract before trusting it.
2. `reusable/check_my_homework.js` escapes text but does not restrict source URL protocols. Do not replace the existing `safeUrl()` HTTP(S) guard with that renderer. It also labels every link "official source" regardless of authority type, and needs focus handling/keyboard verification before adoption.
3. The adapted renderer expects receipt `law_status_as_of`, whereas the sample stores it at answer level; establish explicit inheritance or matching validation.
4. Bill X-Ray examples include ellipses and bracketed editorial additions in passages labeled exact. They illustrate reasoning but must not be imported as exact statutory evidence; current Housing exact-span policy should remain strict.
5. Claimed tests of Bill X-Ray's original repository are reported by the handoff. This review did not independently rerun those tests or verify the whole remote repository. Housing recommendations are proposed, not implemented features.

## Release tests to require

- Structural gate: every claim and referenced receipt resolves; source span is exact; authority/date/status fields valid; unsupported claim blocks publication.
- Semantic review: wrong actor, omitted exemption, wrong number/date, pending-as-law, ambiguous conflict, procedural outcome overclaim and general-to-personal inference adversarial cases. Independent review disagreements stay explicit.
- Real-data UI: six cards, selected address/date remains synchronized, matching evidence per claim, unknown review failure differs from missing fact, no fabricated no-law conclusion, future and failed cases, resolved versus unresolved geography.
- Regression: all existing raw outputs and all 500 address IDs preserved; original predicates and source hashes unchanged by the presentation layer.
- Accessibility: keyboard flow, drawer focus/return/Escape, screen reader labeling, mobile legibility, contrast, plain text safety and HTTP(S)-only citations.
- Human check: ask a nonexpert to find what is supported, what fact is missing, where evidence is and whether a pending law protects them today. Record exact tasks and outcomes, not a blanket readability score. One person's success is limited evidence, not universal validation.

## Recommended order after strategy and external critique

1. Agree answer contract/reason taxonomy and release criteria, retain the raw audit view.
2. Resolve selected controlling-law and consolidation decisions necessary to answer the six questions, leaving explicit gaps where evidence cannot decide.
3. Generate and independently review sourced plain-language claims; no free-form UI model answers.
4. Implement compact resident presentation with scoped homework; preserve condition visibility and query dates.
5. Test actual saved data and human comprehension, then refresh demo/submission claims.

No new legal assertions, no paid calls, no browser execution and no implementation edits were performed in this review.
