"""One independent strategy critique; never changes housing engine or public results."""
import argparse, datetime, hashlib, json, os, pathlib, sys, urllib.request, urllib.error, uuid, zipfile

def critique(response):
    if response.get('stop_reason') != 'end_turn':
        raise ValueError('Review incomplete: stop_reason=' + str(response.get('stop_reason')))
    result='\n\n'.join(x['text'] for x in response.get('content',[]) if x.get('type')=='text')
    if not result.strip(): raise ValueError('Review contained no text')
    return result

def write_json(path, obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')

def build_request(model, prompt):
    if model != 'claude-sonnet-5-5':
        raise ValueError('This reviewed request configuration is scoped to claude-sonnet-5-5.')
    return {'model':model,'max_tokens':8192,
            'thinking':{'type':'between_tools'},'output_config':{'effort':'high'},
            'messages':[{'role':'user','content':prompt}],
            'system':'You are an independent skeptical product and engineering reviewer. Critique the supplied evidence and strategy in concise Markdown. Treat supplied project statements as claims to inspect. Do not certify law, invent test results or imply access to unavailable files. Finish every requested section within 1800 words.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--model',default='claude-sonnet-5-5');a=p.parse_args()
    project=pathlib.Path(a.project)
    if not project.is_dir(): raise SystemExit('Existing project missing; no call made.')
    key=os.environ.get('ANTHROPIC_API_KEY')
    if not key: raise SystemExit('Use the PowerShell window where your existing key is loaded; no call made.')
    packet=pathlib.Path(__file__).with_name('CLAUDE_REVIEW_PACKET.md')
    if not packet.is_file(): raise SystemExit('Review packet missing; no call made.')
    prompt=packet.read_text(encoding='utf-8')
    if len(prompt)>240000: raise SystemExit('Packet unexpectedly large; no call made.')
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
    run=project/'evidence'/'strategy-review'/stamp;run.mkdir(parents=True,exist_ok=False)
    packet_copy=run/packet.name;packet_copy.write_text(prompt,encoding='utf-8')
    request_body=build_request(a.model,prompt)
    write_json(run/'request.json',request_body)
    record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'model_requested':a.model,'packet_sha256':hashlib.sha256(packet_copy.read_bytes()).hexdigest(),'api_call_attempts':0,'review_completed':False,'purpose':'External strategy critique, not legal validation','automatic_retries':0}
    code=1
    try:
        req=urllib.request.Request('https://api.anthropic.com/v1/messages',data=json.dumps(request_body).encode('utf-8'),headers={'x-api-key':key,'anthropic-version':'2023-06-01','content-type':'application/json'},method='POST')
        record['api_call_attempts']=1
        print('Requesting one Claude critique. No automatic retries; app and engine remain unchanged.',flush=True)
        with urllib.request.urlopen(req,timeout=300) as response:
            raw=json.loads(response.read().decode('utf-8')); record['request_id']=response.headers.get('request-id')
        # Never persist a credential even if a remote response unexpectedly echoes it.
        safe=json.loads(json.dumps(raw).replace(key,'[REDACTED]'))
        write_json(run/'response.json',safe)
        record.update(model_returned=safe.get('model'),usage=safe.get('usage'),stop_reason=safe.get('stop_reason'))
        result=critique(safe);(run/'CLAUDE_FEEDBACK.md').write_text(result,encoding='utf-8')
        record['review_completed']=True;code=0
    except urllib.error.HTTPError as e:
        record['failure']='HTTP '+str(e.code)+'; no automatic retry. Inspect account/model access privately.'
    except Exception as e:
        record['failure']=str(e).replace(key,'[REDACTED]')
    finally:
        write_json(run/'REVIEW_RECEIPT.json',record)
        downloads=pathlib.Path.home()/'Downloads';downloads.mkdir(exist_ok=True)
        archive=downloads/('Housing_Claude_Strategy_Return-'+stamp+'.zip')
        with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
            for file in sorted(run.iterdir()): z.write(file,stamp+'/'+file.name)
        print('RETURN ZIP: '+str(archive));print('Review complete.' if code==0 else 'Review stopped: '+record.get('failure','Unknown failure'))
    return code
if __name__=='__main__':sys.exit(main())
