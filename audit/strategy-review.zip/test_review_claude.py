import unittest
from review_claude import critique, build_request
class ReviewGateTests(unittest.TestCase):
    def test_complete(self):
        self.assertEqual(critique({'stop_reason':'end_turn','content':[{'type':'text','text':'Critique'}]}),'Critique')
    def test_truncated_is_not_finished(self):
        with self.assertRaises(ValueError): critique({'stop_reason':'max_tokens','content':[{'type':'text','text':'Partial'}]})
    def test_refusal_not_finished(self):
        with self.assertRaises(ValueError): critique({'stop_reason':'refusal','content':[{'type':'text','text':'No'}]})
    def test_empty_not_finished(self):
        with self.assertRaises(ValueError): critique({'stop_reason':'end_turn','content':[]})
class RequestConfigTests(unittest.TestCase):
    def test_explicit_written_response_configuration(self):
        r=build_request('claude-sonnet-5-5','packet')
        self.assertEqual(r['thinking']['type'],'between_tools')
        self.assertEqual(r['output_config']['effort'],'high')
        self.assertEqual(r['max_tokens'],8192)
        self.assertNotIn('tools',r)
    def test_different_model_cannot_reuse_configuration(self):
        with self.assertRaises(ValueError): build_request('different-model','packet')
if __name__=='__main__':unittest.main()
